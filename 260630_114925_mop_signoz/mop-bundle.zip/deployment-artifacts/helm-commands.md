# BOS Genesis generated deployment artifact commands

No mutation was performed while generating this bundle.

## Helm dry-run render
helm template agent-ai-signoz ./helm-chart/extracted/signoz `
  --namespace agent-testing `
  --values ./helm-values/values-agent-ai-signoz.yaml `
  --version 0.122.0 > ./rendered-manifests/agent-ai-signoz-rendered.yaml

## Helm dry-run install
helm upgrade --install agent-ai-signoz ./helm-chart/extracted/signoz `
  --namespace agent-testing `
  --create-namespace `
  --values ./helm-values/values-agent-ai-signoz.yaml `
  --dry-run

## Governed mutation command, only after dry-run and approval
helm upgrade --install agent-ai-signoz ./helm-chart/extracted/signoz `
  --namespace agent-testing `
  --create-namespace `
  --values ./helm-values/values-agent-ai-signoz.yaml `
  --atomic `
  --timeout 10m

## Agent-generated ingress, apply only after Helm services exist
kubectl apply -f ./kubernetes-manifests/ingress-agent-ai-signoz.yaml
