---
artifact_type: mop_installation_notes
source_namespace: signoz
target_namespace_placeholder: generic-namespace
generated_release_name: agent-ai-signoz
generated_at: 20260629T012547Z
run_id: mop_89cd2ac38d484f5b995a2394071b9a98
---

# Installation Notes: signoz to generic-namespace

## Purpose

Provide operator guidance for reviewing and later executing the generated deployment artifact bundle for `signoz` into `generic-namespace`.

## Execution Constraints

- Artifact generation performed no mutation.
- Dry-run/render is allowed.
- Human approval is required before applying namespace, Helm, ingress, CRDs, or any other resource.
- Kubernetes Secret values are excluded from all generated artifacts.

## Required Inputs

- Target cluster context.
- Execution-time target namespace supplied by MoP Execution.
- Approved secret values, if the chart requires them.
- Human approval/change ticket before mutation.

## Evidence Summary

- Change intent: Generate MoP in both markdown and PDF format so we can fully clone the source namespace
- Environment: kubernetes_generic
- Chart: signoz 0.122.0
- Generated release: agent-ai-signoz
- Values files: helm-values/values-agent-ai-signoz.yaml
- Rendered manifests: rendered-manifests/agent-ai-signoz-rendered.yaml

## Artifact Bundle Contents

```text
artifact.json
machine_execution_plan.yaml
mop-signoz-to-generic-namespace-20260629T012547Z.human-mop.md
mop-signoz-to-generic-namespace-20260629T012547Z.installation.md
mop-signoz-to-generic-namespace-20260629T012547Z.pdf
deployment-artifacts/
  artifact-index.json
  helm-commands.md
  helm-chart/
  helm-values/
  kubernetes-manifests/
  rendered-manifests/
deployment-artifacts.zip
mop-bundle.zip
```

## Warnings

- No warnings.

## Operator Flow

1. Inspect `artifact.json` and `deployment-artifacts/artifact-index.json`.
2. Download `mop-bundle.zip` for the complete run package, or unzip `deployment-artifacts.zip` for deployment-only files.
3. Review `helm-values/values-agent-ai-signoz.yaml`.
4. Run the render and dry-run commands from `helm-commands.md`.
5. Request approval.
6. Execute only the approved commands.
7. Validate target resources.
