---
artifact_type: installation_notes
schema_version: "1.0"
agent: bosgenesis-mop-creation-agent
mop_id: "d1d1ab47-1778-4ec6-b186-30f6a85e1756"
run_id: "ced05499-3456-4ac6-8b49-c715f03ca17a"
correlation_id: "mop_19934809ab3440b18dd7c64badce81a0"
generated_at: "2026-07-05T02:10:53.417427+00:00"
source_namespace: "bosgenesis"
target_namespace: "agent-testing"
generation_mode: "platform-only"
source_snapshot: "af085c21-888c-49f8-ada0-5da4535067e0"
status: "generated"
no_secret_values: true
no_production_data: true
qdrant_lookup_status: "references_found"
qdrant_reference_count: 5
memory_context_status: "ok"
memory_context_read_count: 5
---

# Installation Notes: bosgenesis to agent-testing

## 1. Purpose

Recreate the Kubernetes/Helm installation footprint from source namespace `bosgenesis` into target namespace `agent-testing` without copying production data.

These notes are optimized for an autonomous LLM/agent executor. The executor must still require human approval before mutating any cluster or application system.

## 2. Execution Constraints

- Scope is one namespace only.
- Target namespace is `agent-testing`.
- Use public repositories only.
- Do not copy Kubernetes Secret values.
- Do not copy database rows, MongoDB documents, Kafka messages, Redis values, files, or business payloads.
- Run dry-run commands before real apply/install commands.
- Treat inferred steps as requiring human confirmation.
- Treat Qdrant references as prior guidance only, not current observed facts.
- Treat memory context as prior non-secret generation context only, not current observed facts.

## 3. Required Human Inputs

```yaml
required_human_inputs:
  []
```

## 4. Evidence Summary

```yaml
evidence:
  source_snapshot: "af085c21-888c-49f8-ada0-5da4535067e0"
  kubernetes_mcp:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[k8s_inspector_mcp]
  helm_mcp:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[helm_manager_mcp]
  data_ingestion:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[data_ingestion_mcp]
  qdrant_prior_references:
    status: "references_found"
    count: 5
    references:
  - reference_id: 7bc7e66d-53ee-58f3-a559-d2467d301bd7
    citation_label: prior_reference_only_not_current_fact
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    source_artifact_type: human_mop_markdown
    source_namespace: bosgenesis
    component: HelmRelease/bosgenesis-k8s-data-ingestion-agent
    score: 0.9833
    confidence: high
    matched_fields: kind, name, helm_release_name, helm_chart_name, text_terms
    redaction_status: redacted
  - reference_id: 1eaae97f-54b9-5788-bcc1-81ecb5ea8f6e
    citation_label: prior_reference_only_not_current_fact
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    source_artifact_type: human_mop_markdown
    source_namespace: bosgenesis
    component: HelmRelease/bosgenesis-mop-creation-agent
    score: 0.9833
    confidence: high
    matched_fields: kind, name, helm_release_name, helm_chart_name, text_terms
    redaction_status: redacted
  - reference_id: 75d33ee0-f29c-5779-af7f-59ab210aebc6
    citation_label: prior_reference_only_not_current_fact
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    source_artifact_type: human_mop_markdown
    source_namespace: bosgenesis
    component: HelmRelease/clickhouse
    score: 0.9833
    confidence: high
    matched_fields: kind, name, helm_release_name, helm_chart_name, text_terms
    redaction_status: redacted
  - reference_id: 43872ffc-f251-5b9c-be40-80cd8a87f193
    citation_label: prior_reference_only_not_current_fact
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    source_artifact_type: human_mop_markdown
    source_namespace: bosgenesis
    component: HelmRelease/kafka
    score: 0.9833
    confidence: high
    matched_fields: kind, name, helm_release_name, helm_chart_name, text_terms
    redaction_status: redacted
  - reference_id: 18ee328e-d93d-57ec-9987-1f8cbd5c47ef
    citation_label: prior_reference_only_not_current_fact
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    source_artifact_type: human_mop_markdown
    source_namespace: bosgenesis
    component: HelmRelease/kafka-ui
    score: 0.9833
    confidence: high
    matched_fields: kind, name, helm_release_name, helm_chart_name, text_terms
    redaction_status: redacted
  memory_context:
    status: "ok"
    count: 5
    authority: prior_context_only_not_current_fact
    records:
  - memory_id: mem-733ce88fa4f82653
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=17; raw_k8s=62; warning_only=50. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-f4d755de3d37c67f
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=229,
  helm_releases=17, raw_k8s=62, warning_only=50, qdrant_references=5, warnings=47.
...
  - memory_id: mem-065be6e8ff807aac
    kind: short_term
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=229,
  helm_releases=17, raw_k8s=62, warning_only=50, qdrant_references=5, warnings=47.
...
  - memory_id: mem-592c50b2bdd550eb
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=17; raw_k8s=62; warning_only=50. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-b291ae367bae67bc
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=229,
  helm_releases=17, raw_k8s=62, warning_only=50, qdrant_references=5, warnings=47.
...
```

## 5. Resource Inventory Summary

```yaml
inventory:
  helm_releases:
  - release_name: bosgenesis-k8s-data-ingestion-agent
    namespace: bosgenesis
    chart_name: bosgenesis-k8s-data-ingestion-agent-0.1.0
    chart_version: 0.1.0
    status: deployed
  - release_name: bosgenesis-mop-creation-agent
    namespace: bosgenesis
    chart_name: bosgenesis-mop-creation-agent-0.1.0
    chart_version: 0.1.0
    status: deployed
  - release_name: bosgenesis-mop-execution-agent
    namespace: bosgenesis
    chart_name: bosgenesis-mop-execution-agent-0.1.0
    chart_version: 0.1.0
    status: deployed
  - release_name: bosgenesis-release-note-agent
    namespace: bosgenesis
    chart_name: bosgenesis-release-note-agent-0.1.0
    chart_version: 0.1.0
    status: deployed
  - release_name: clickhouse
    namespace: bosgenesis
    chart_name: clickhouse-9.4.4
    chart_version: 9.4.4
    status: deployed
  - release_name: kafka
    namespace: bosgenesis
    chart_name: kafka-32.4.3
    chart_version: 32.4.3
    status: deployed
  - release_name: kafka-ui
    namespace: bosgenesis
    chart_name: kafka-ui-0.7.6
    chart_version: 0.7.6
    status: deployed
  - release_name: langfuse
    namespace: bosgenesis
    chart_name: langfuse-1.5.29
    chart_version: 1.5.29
    status: deployed
  - release_name: mongodb
    namespace: bosgenesis
    chart_name: mongodb-18.6.21
    chart_version: 18.6.21
    status: deployed
  - release_name: n8n
    namespace: bosgenesis
    chart_name: n8n-1.0.0
    chart_version: 1.0.0
    status: deployed
  - release_name: ollama
    namespace: bosgenesis
    chart_name: ollama-1.56.0
    chart_version: 1.56.0
    status: deployed
  - release_name: ollama-llama70b
    namespace: bosgenesis
    chart_name: ollama-1.56.0
    chart_version: 1.56.0
    status: deployed
  - release_name: open-webui
    namespace: bosgenesis
    chart_name: open-webui-14.5.0
    chart_version: 14.5.0
    status: deployed
  - release_name: postgresql
    namespace: bosgenesis
    chart_name: postgresql-18.5.6
    chart_version: 18.5.6
    status: deployed
  - release_name: qdrant
    namespace: bosgenesis
    chart_name: qdrant-1.17.0
    chart_version: 1.17.0
    status: deployed
  - release_name: redis
    namespace: bosgenesis
    chart_name: redis-25.3.9
    chart_version: 25.3.9
    status: deployed
  - release_name: supabase
    namespace: bosgenesis
    chart_name: supabase-0.5.4
    chart_version: 0.5.4
    status: deployed
  raw_kubernetes_resources:
  - kind: ConfigMap
    name: bosgenesis-helm-manager-mcp-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:bosgenesis-helm-manager-mcp-config
  - kind: ConfigMap
    name: bosgenesis-k8s-inspector-mcp-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:bosgenesis-k8s-inspector-mcp-config
  - kind: ConfigMap
    name: dify-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:dify-config
  - kind: ConfigMap
    name: istio-ca-crl
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:istio-ca-crl
  - kind: ConfigMap
    name: istio-ca-root-cert
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:istio-ca-root-cert
  - kind: ConfigMap
    name: kube-root-ca.crt
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:kube-root-ca.crt
  - kind: ConfigMap
    name: langflow-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:langflow-config
  - kind: ConfigMap
    name: letta-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:letta-config
  - kind: ConfigMap
    name: memory-agent-config
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: ConfigMap:bosgenesis:memory-agent-config
  - kind: Deployment
    name: bos-mcp-clickhouse
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bos-mcp-clickhouse
  - kind: Deployment
    name: bos-mcp-mongodb
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bos-mcp-mongodb
  - kind: Deployment
    name: bos-mcp-qdrant
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bos-mcp-qdrant
  - kind: Deployment
    name: bos-mcp-qdrant-docs
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bos-mcp-qdrant-docs
  - kind: Deployment
    name: bosgenesis-helm-manager-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bosgenesis-helm-manager-mcp
  - kind: Deployment
    name: bosgenesis-k8s-inspector-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bosgenesis-k8s-inspector-mcp
  - kind: Deployment
    name: bosgenesis-memory-agent-api
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:bosgenesis-memory-agent-api
  - kind: Deployment
    name: ch-ui
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:ch-ui
  - kind: Deployment
    name: dify-api
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:dify-api
  - kind: Deployment
    name: dify-plugin-daemon
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:dify-plugin-daemon
  - kind: Deployment
    name: dify-web
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:dify-web
  - kind: Deployment
    name: dify-worker
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:dify-worker
  - kind: Deployment
    name: langflow
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:langflow
  - kind: Deployment
    name: letta
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:letta
  - kind: Deployment
    name: redisinsight
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Deployment:bosgenesis:redisinsight
  - kind: Ingress
    name: bosgenesis-helm-manager-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:bosgenesis-helm-manager-mcp
  - kind: Ingress
    name: bosgenesis-k8s-inspector-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:bosgenesis-k8s-inspector-mcp
  - kind: Ingress
    name: ch-ui
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:ch-ui
  - kind: Ingress
    name: clickhouse-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:clickhouse-mcp
  - kind: Ingress
    name: dify
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:dify
  - kind: Ingress
    name: langflow-ingress
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:langflow-ingress
  - kind: Ingress
    name: langfuse
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:langfuse
  - kind: Ingress
    name: letta
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:letta
  - kind: Ingress
    name: memory-agent-ingress
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:memory-agent-ingress
  - kind: Ingress
    name: mongodb-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:mongodb-mcp
  - kind: Ingress
    name: ollama
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:ollama
  - kind: Ingress
    name: ollama-llama70b
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:ollama-llama70b
  - kind: Ingress
    name: open-webui
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:open-webui
  - kind: Ingress
    name: qdrant
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:qdrant
  - kind: Ingress
    name: qdrant-docs-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:qdrant-docs-mcp
  - kind: Ingress
    name: qdrant-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:qdrant-mcp
  - kind: Ingress
    name: redisinsight
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Ingress:bosgenesis:redisinsight
  - kind: PersistentVolumeClaim
    name: ch-ui
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:ch-ui
  - kind: PersistentVolumeClaim
    name: dify-storage
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:dify-storage
  - kind: PersistentVolumeClaim
    name: langflow-pvc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:langflow-pvc
  - kind: PersistentVolumeClaim
    name: memory-agent-lancedb-pvc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:memory-agent-lancedb-pvc
  - kind: PersistentVolumeClaim
    name: ollama
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:ollama
  - kind: PersistentVolumeClaim
    name: redisinsight-pvc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: PersistentVolumeClaim:bosgenesis:redisinsight-pvc
  - kind: Service
    name: bos-mcp-clickhouse-svc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bos-mcp-clickhouse-svc
  - kind: Service
    name: bos-mcp-mongodb-svc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bos-mcp-mongodb-svc
  - kind: Service
    name: bos-mcp-qdrant-docs-svc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bos-mcp-qdrant-docs-svc
  - kind: Service
    name: bos-mcp-qdrant-svc
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bos-mcp-qdrant-svc
  - kind: Service
    name: bosgenesis-helm-manager-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bosgenesis-helm-manager-mcp
  - kind: Service
    name: bosgenesis-k8s-inspector-mcp
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bosgenesis-k8s-inspector-mcp
  - kind: Service
    name: bosgenesis-memory-agent-api
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:bosgenesis-memory-agent-api
  - kind: Service
    name: ch-ui
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:ch-ui
  - kind: Service
    name: dify-api
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:dify-api
  - kind: Service
    name: dify-plugin-daemon
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:dify-plugin-daemon
  - kind: Service
    name: dify-web
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:dify-web
  - kind: Service
    name: langflow
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:langflow
  - kind: Service
    name: letta
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:letta
  - kind: Service
    name: mongodb-nodeport
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:mongodb-nodeport
  - kind: Service
    name: redisinsight
    namespace: bosgenesis
    source: k8s_inspector_mcp
    entity_key: Service:bosgenesis:redisinsight
  application_targets:
  []
  excluded_resources:
  []
  warnings:
  - data_ingestion_mcp_tools_list_failed: unhandled errors in a TaskGroup (1 sub-exception)
  - manual_review_required:Pod:49_runtime_artifacts_skipped
  - manual_review_required:Event/unknown:unsupported_namespaced_resource_manual_note
  - raw_manifest:Ingress/bosgenesis-helm-manager-mcp:ingress_name_prefixed_from:bosgenesis-helm-manager-mcp
  - raw_manifest:Ingress/bosgenesis-k8s-inspector-mcp:ingress_name_prefixed_from:bosgenesis-k8s-inspector-mcp
  - raw_manifest:Ingress/ch-ui:ingress_name_prefixed_from:ch-ui
  - raw_manifest:Ingress/clickhouse-mcp:ingress_name_prefixed_from:clickhouse-mcp
  - raw_manifest:Ingress/dify:ingress_name_prefixed_from:dify
  - raw_manifest:Ingress/langflow-ingress:ingress_name_prefixed_from:langflow-ingress
  - raw_manifest:Ingress/langfuse:ingress_backend_service_rewritten:langfuse-web->agent-ai-langfuse-web
  - raw_manifest:Ingress/langfuse:ingress_name_prefixed_from:langfuse
  - raw_manifest:Ingress/letta:ingress_name_prefixed_from:letta
  - raw_manifest:Ingress/memory-agent-ingress:ingress_name_prefixed_from:memory-agent-ingress
  - raw_manifest:Ingress/mongodb-mcp:ingress_name_prefixed_from:mongodb-mcp
  - raw_manifest:Ingress/ollama:ingress_backend_service_rewritten:ollama->agent-ai-ollama
  - raw_manifest:Ingress/ollama:ingress_name_prefixed_from:ollama
  - raw_manifest:Ingress/ollama-llama70b:ingress_backend_service_rewritten:ollama-llama70b->agent-ai-ollama-llama70b
  - raw_manifest:Ingress/ollama-llama70b:ingress_name_prefixed_from:ollama-llama70b
  - raw_manifest:Ingress/open-webui:ingress_backend_service_rewritten:open-webui->agent-ai-open-webui
  - raw_manifest:Ingress/open-webui:ingress_name_prefixed_from:open-webui
  - raw_manifest:Ingress/qdrant:ingress_backend_service_rewritten:qdrant->agent-ai-qdrant
  - raw_manifest:Ingress/qdrant:ingress_name_prefixed_from:qdrant
  - raw_manifest:Ingress/qdrant-docs-mcp:ingress_name_prefixed_from:qdrant-docs-mcp
  - raw_manifest:Ingress/qdrant-mcp:ingress_name_prefixed_from:qdrant-mcp
  - raw_manifest:Ingress/redisinsight:ingress_name_prefixed_from:redisinsight
  - raw_manifest:Ingress/bosgenesis-k8s-data-ingestion-agent:ingress_backend_service_rewritten:bosgenesis-k8s-data-ingestion-agent->agent-ai-bosgenesis-k8s-data-ingestion-agent
  - raw_manifest:Ingress/bosgenesis-k8s-data-ingestion-agent:ingress_name_prefixed_from:bosgenesis-k8s-data-ingestion-agent
  - raw_manifest:Ingress/bosgenesis-k8s-data-ingestion-agent:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/bosgenesis-mop-creation-agent:ingress_backend_service_rewritten:bosgenesis-mop-creation-agent->agent-ai-bosgenesis-mop-creation-agent
  - raw_manifest:Ingress/bosgenesis-mop-creation-agent:ingress_name_prefixed_from:bosgenesis-mop-creation-agent
  - raw_manifest:Ingress/bosgenesis-mop-creation-agent:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/bosgenesis-mop-execution-agent:ingress_backend_service_rewritten:bosgenesis-mop-execution-agent->agent-ai-bosgenesis-mop-execution-agent
  - raw_manifest:Ingress/bosgenesis-mop-execution-agent:ingress_name_prefixed_from:bosgenesis-mop-execution-agent
  - raw_manifest:Ingress/bosgenesis-mop-execution-agent:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/bosgenesis-release-note-agent:ingress_backend_service_rewritten:bosgenesis-release-note-agent-api->agent-ai-bosgenesis-release-note-agent-api
  - raw_manifest:Ingress/bosgenesis-release-note-agent:ingress_backend_service_rewritten:bosgenesis-release-note-agent-mcp->agent-ai-bosgenesis-release-note-agent-mcp
  - raw_manifest:Ingress/bosgenesis-release-note-agent:ingress_name_prefixed_from:bosgenesis-release-note-agent
  - raw_manifest:Ingress/bosgenesis-release-note-agent:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/kafka-ui:ingress_backend_service_rewritten:kafka-ui->agent-ai-kafka-ui
  - raw_manifest:Ingress/kafka-ui:ingress_name_prefixed_from:kafka-ui
  - raw_manifest:Ingress/kafka-ui:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/n8n-main:ingress_backend_service_rewritten:n8n-main->agent-ai-n8n-main
  - raw_manifest:Ingress/n8n-main:ingress_name_prefixed_from:n8n-main
  - raw_manifest:Ingress/n8n-main:ingress_reconstructed_from_helm_managed_source
  - raw_manifest:Ingress/supabase-supabase-kong:ingress_backend_service_rewritten:supabase-supabase-kong->agent-ai-supabase-supabase-kong
  - raw_manifest:Ingress/supabase-supabase-kong:ingress_name_prefixed_from:supabase-supabase-kong
  - raw_manifest:Ingress/supabase-supabase-kong:ingress_reconstructed_from_helm_managed_source
```

## 6. Dependency Graph

```yaml
dependency_order:
  - phase: verify_access
    depends_on: []
  - phase: prepare_target_namespace
    depends_on: [verify_access]
  - phase: prepare_secret_placeholders
    depends_on: [prepare_target_namespace]
  - phase: apply_configmaps
    depends_on: [prepare_secret_placeholders]
  - phase: apply_pvcs
    depends_on: [prepare_target_namespace]
  - phase: install_helm_releases
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
  - phase: apply_raw_kubernetes_resources
    depends_on: [install_helm_releases, apply_configmaps, apply_pvcs]
  - phase: apply_ingress
    depends_on: [apply_raw_kubernetes_resources]
  - phase: apply_application_metadata
    depends_on: [apply_raw_kubernetes_resources]
    enabled_when: generation_mode == "application"
  - phase: validate
    depends_on: [apply_ingress, apply_application_metadata]
```

## 7. Machine Execution Plan

This block is the canonical machine-readable execution contract. A downstream agent should parse this YAML first, then use the remaining sections as human-readable supporting detail.

```yaml
machine_execution_plan:
  schema_version: '1.0'
  authority_order: observed_evidence > deterministic_normalization > llm_suggestion > human_fill_in
  executor_contract:
    parse_this_block_first: true
    dry_run_before_mutation: true
    human_approval_before_mutation: true
    never_copy_secret_values: true
    target_namespace_only: agent-testing
    llm_suggestions_are_not_authority: true
    qdrant_references_are_prior_guidance_only: true
  prior_references:
  - reference_id: 7bc7e66d-53ee-58f3-a559-d2467d301bd7
    citation_label: prior_reference_only_not_current_fact
    component: HelmRelease/bosgenesis-k8s-data-ingestion-agent
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    score: 0.9833
    matched_fields:
    - kind
    - name
    - helm_release_name
    - helm_chart_name
    - text_terms
  - reference_id: 1eaae97f-54b9-5788-bcc1-81ecb5ea8f6e
    citation_label: prior_reference_only_not_current_fact
    component: HelmRelease/bosgenesis-mop-creation-agent
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    score: 0.9833
    matched_fields:
    - kind
    - name
    - helm_release_name
    - helm_chart_name
    - text_terms
  - reference_id: 75d33ee0-f29c-5779-af7f-59ab210aebc6
    citation_label: prior_reference_only_not_current_fact
    component: HelmRelease/clickhouse
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    score: 0.9833
    matched_fields:
    - kind
    - name
    - helm_release_name
    - helm_chart_name
    - text_terms
  - reference_id: 43872ffc-f251-5b9c-be40-80cd8a87f193
    citation_label: prior_reference_only_not_current_fact
    component: HelmRelease/kafka
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    score: 0.9833
    matched_fields:
    - kind
    - name
    - helm_release_name
    - helm_chart_name
    - text_terms
  - reference_id: 18ee328e-d93d-57ec-9987-1f8cbd5c47ef
    citation_label: prior_reference_only_not_current_fact
    component: HelmRelease/kafka-ui
    source_mop_id: b36827d3-03cc-48ca-a011-a4f6d6999851
    score: 0.9833
    matched_fields:
    - kind
    - name
    - helm_release_name
    - helm_chart_name
    - text_terms
  dependency_graph:
  - phase_id: verify_access
    depends_on: []
  - phase_id: prepare_target_namespace
    depends_on:
    - verify_access
  - phase_id: prepare_secret_placeholders
    depends_on:
    - prepare_target_namespace
  - phase_id: apply_configmaps
    depends_on:
    - prepare_secret_placeholders
  - phase_id: apply_pvcs
    depends_on:
    - prepare_target_namespace
  - phase_id: install_helm_releases
    depends_on:
    - apply_configmaps
    - apply_pvcs
    - prepare_secret_placeholders
  - phase_id: apply_raw_kubernetes_resources
    depends_on:
    - install_helm_releases
    - apply_configmaps
    - apply_pvcs
  - phase_id: apply_ingress
    depends_on:
    - apply_raw_kubernetes_resources
  - phase_id: apply_application_metadata
    depends_on:
    - apply_raw_kubernetes_resources
  - phase_id: validate
    depends_on:
    - apply_ingress
    - apply_application_metadata
  required_human_inputs: []
  phases:
  - phase_id: verify_access
    depends_on: []
    objective: Confirm artifact bundle, source evidence, and target namespace intent.
    steps:
    - step_id: verify-artifact-bundle
      phase_id: verify_access
      title: Verify generated artifact bundle
      type: context_check
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed
        confidence: high
        rationale: The artifact bundle is produced by this agent before execution.
      commands:
      - kind: check
        command: test -f artifact.json && test -d generated && test -d values
      expected_outcomes:
      - artifact.json, generated/, and values/ are present.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: prepare_target_namespace
    depends_on:
    - verify_access
    objective: Ensure the target namespace exists before namespaced resources are applied.
    steps:
    - step_id: prepare-target-namespace
      phase_id: prepare_target_namespace
      title: Ensure namespace agent-testing exists
      type: namespace
      depends_on: []
      evidence_refs:
      - generation_request.target_namespace
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: human_input_required
        confidence: high
        rationale: The target namespace is supplied by the generation request.
      commands:
      - kind: check
        command: kubectl get namespace agent-testing
      - kind: apply
        command: kubectl get namespace agent-testing || kubectl create namespace agent-testing
      expected_outcomes:
      - Namespace agent-testing exists.
      required_human_inputs: []
      rollback_commands:
      - 'kubectl delete namespace agent-testing # only if created for this change and cleanup is approved'
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: prepare_secret_placeholders
    depends_on:
    - prepare_target_namespace
    objective: Collect approved secret values without copying source Secret data.
    steps:
    - step_id: secret-values-not-generated
      phase_id: prepare_secret_placeholders
      title: Confirm no generated Secret values are present
      type: human_input
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: human_input_required
        confidence: high
        rationale: Secret values are excluded by policy and must not appear in artifacts.
      commands: []
      expected_outcomes:
      - Required human inputs are confirmed before execution continues.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_configmaps
    depends_on:
    - prepare_secret_placeholders
    objective: Apply generated ConfigMap manifests after namespace rewrite.
    steps:
    - step_id: apply_configmaps-1-configmap-bosgenesis-helm-manager-mcp-config
      phase_id: apply_configmaps
      title: Apply ConfigMap bosgenesis-helm-manager-mcp-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-helm-manager-mcp-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-bosgenesis-helm-manager-mcp-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap bosgenesis-helm-manager-mcp-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap bosgenesis-helm-manager-mcp-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-2-configmap-bosgenesis-k8s-inspector-mcp-config
      phase_id: apply_configmaps
      title: Apply ConfigMap bosgenesis-k8s-inspector-mcp-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-k8s-inspector-mcp-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap bosgenesis-k8s-inspector-mcp-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap bosgenesis-k8s-inspector-mcp-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-3-configmap-dify-config
      phase_id: apply_configmaps
      title: Apply ConfigMap dify-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:dify-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-dify-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-dify-config.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-dify-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap dify-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap dify-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-dify-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-4-configmap-istio-ca-crl
      phase_id: apply_configmaps
      title: Apply ConfigMap istio-ca-crl
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-crl
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-crl.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap istio-ca-crl -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-crl exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-istio-ca-crl.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-5-configmap-istio-ca-root-cert
      phase_id: apply_configmaps
      title: Apply ConfigMap istio-ca-root-cert
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-root-cert
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-root-cert.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-root-cert exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-6-configmap-kube-root-ca.crt
      phase_id: apply_configmaps
      title: Apply ConfigMap kube-root-ca.crt
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:kube-root-ca.crt
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-kube-root-ca.crt.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap kube-root-ca.crt exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-7-configmap-langflow-config
      phase_id: apply_configmaps
      title: Apply ConfigMap langflow-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:langflow-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-langflow-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-langflow-config.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-langflow-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap langflow-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap langflow-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-langflow-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-8-configmap-letta-config
      phase_id: apply_configmaps
      title: Apply ConfigMap letta-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:letta-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-letta-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-letta-config.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-letta-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap letta-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap letta-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-letta-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-9-configmap-memory-agent-config
      phase_id: apply_configmaps
      title: Apply ConfigMap memory-agent-config
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:memory-agent-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-memory-agent-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-memory-agent-config.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-memory-agent-config.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap memory-agent-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap memory-agent-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-memory-agent-config.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_pvcs
    depends_on:
    - prepare_target_namespace
    objective: Apply approved PersistentVolumeClaim manifests.
    steps:
    - step_id: apply_pvcs-1-persistentvolumeclaim-ch-ui
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim ch-ui
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim ch-ui -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_pvcs-2-persistentvolumeclaim-dify-storage
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim dify-storage
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:dify-storage
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-dify-storage.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim dify-storage -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim dify-storage exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_pvcs-3-persistentvolumeclaim-langflow-pvc
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim langflow-pvc
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:langflow-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-langflow-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim langflow-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim langflow-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_pvcs-4-persistentvolumeclaim-memory-agent-lancedb-pvc
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim memory-agent-lancedb-pvc
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:memory-agent-lancedb-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim memory-agent-lancedb-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim memory-agent-lancedb-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_pvcs-5-persistentvolumeclaim-ollama
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim ollama
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ollama
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-ollama.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim ollama -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim ollama exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_pvcs-6-persistentvolumeclaim-redisinsight-pvc
      phase_id: apply_pvcs
      title: Apply PersistentVolumeClaim redisinsight-pvc
      type: pvc
      depends_on:
      - prepare_target_namespace
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:redisinsight-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-redisinsight-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing
      - kind: validate
        command: kubectl get persistentvolumeclaim redisinsight-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim redisinsight-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: install_helm_releases
    depends_on:
    - apply_configmaps
    - apply_pvcs
    - prepare_secret_placeholders
    objective: Install or upgrade Helm-managed components with redacted values files.
    steps:
    - step_id: helm-1-agent-ai-bosgenesis-k8s-data-ingestion-agent
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-k8s-data-ingestion-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0
          --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
          --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0
          --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
          --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-k8s-data-ingestion-agent
      source_release_name: bosgenesis-k8s-data-ingestion-agent
      chart_ref: bosgenesis-k8s-data-ingestion-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-2-agent-ai-bosgenesis-mop-creation-agent
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-bosgenesis-mop-creation-agent
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-creation-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-mop-creation-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --atomic
          --timeout 10m
      - kind: validate
        command: helm status agent-ai-bosgenesis-mop-creation-agent -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-bosgenesis-mop-creation-agent is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-bosgenesis-mop-creation-agent -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-mop-creation-agent
      source_release_name: bosgenesis-mop-creation-agent
      chart_ref: bosgenesis-mop-creation-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-3-agent-ai-bosgenesis-mop-execution-agent
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-bosgenesis-mop-execution-agent
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-execution-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-mop-execution-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --atomic
          --timeout 10m
      - kind: validate
        command: helm status agent-ai-bosgenesis-mop-execution-agent -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-bosgenesis-mop-execution-agent is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-bosgenesis-mop-execution-agent -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-mop-execution-agent
      source_release_name: bosgenesis-mop-execution-agent
      chart_ref: bosgenesis-mop-execution-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-4-agent-ai-bosgenesis-release-note-agent
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-bosgenesis-release-note-agent
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-release-note-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-release-note-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace
          agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --atomic
          --timeout 10m
      - kind: validate
        command: helm status agent-ai-bosgenesis-release-note-agent -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-bosgenesis-release-note-agent is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-bosgenesis-release-note-agent -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-release-note-agent
      source_release_name: bosgenesis-release-note-agent
      chart_ref: bosgenesis-release-note-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-5-agent-ai-clickhouse
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-clickhouse
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:clickhouse
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-clickhouse.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing --create-namespace
          --version 9.4.4 -f values/values-agent-ai-clickhouse.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing --create-namespace
          --version 9.4.4 -f values/values-agent-ai-clickhouse.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-clickhouse -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-clickhouse is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-clickhouse -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-clickhouse
      source_release_name: clickhouse
      chart_ref: clickhouse-9.4.4
      chart_version: 9.4.4
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-6-agent-ai-kafka
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-kafka
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-kafka.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-kafka kafka-32.4.3 --namespace agent-testing --create-namespace --version
          32.4.3 -f values/values-agent-ai-kafka.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-kafka kafka-32.4.3 --namespace agent-testing --create-namespace --version
          32.4.3 -f values/values-agent-ai-kafka.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-kafka -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-kafka is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-kafka -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-kafka
      source_release_name: kafka
      chart_ref: kafka-32.4.3
      chart_version: 32.4.3
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-7-agent-ai-kafka-ui
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-kafka-ui
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka-ui
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-kafka-ui.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing --create-namespace --version
          0.7.6 -f values/values-agent-ai-kafka-ui.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing --create-namespace --version
          0.7.6 -f values/values-agent-ai-kafka-ui.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-kafka-ui -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-kafka-ui is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-kafka-ui -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-kafka-ui
      source_release_name: kafka-ui
      chart_ref: kafka-ui-0.7.6
      chart_version: 0.7.6
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-8-agent-ai-langfuse
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-langfuse
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:langfuse
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-langfuse.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing --create-namespace --version
          1.5.29 -f values/values-agent-ai-langfuse.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing --create-namespace --version
          1.5.29 -f values/values-agent-ai-langfuse.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-langfuse -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-langfuse is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-langfuse -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-langfuse
      source_release_name: langfuse
      chart_ref: langfuse-1.5.29
      chart_version: 1.5.29
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-9-agent-ai-mongodb
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-mongodb
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:mongodb
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-mongodb.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing --create-namespace --version
          18.6.21 -f values/values-agent-ai-mongodb.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing --create-namespace --version
          18.6.21 -f values/values-agent-ai-mongodb.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-mongodb -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-mongodb is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-mongodb -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-mongodb
      source_release_name: mongodb
      chart_ref: mongodb-18.6.21
      chart_version: 18.6.21
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-10-agent-ai-n8n
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-n8n
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:n8n
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-n8n.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-n8n n8n-1.0.0 --namespace agent-testing --create-namespace --version 1.0.0
          -f values/values-agent-ai-n8n.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-n8n n8n-1.0.0 --namespace agent-testing --create-namespace --version 1.0.0
          -f values/values-agent-ai-n8n.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-n8n -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-n8n is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-n8n -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-n8n
      source_release_name: n8n
      chart_ref: n8n-1.0.0
      chart_version: 1.0.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-11-agent-ai-ollama
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-ollama
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-ollama.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-ollama ollama-1.56.0 --namespace agent-testing --create-namespace --version
          1.56.0 -f values/values-agent-ai-ollama.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-ollama ollama-1.56.0 --namespace agent-testing --create-namespace --version
          1.56.0 -f values/values-agent-ai-ollama.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-ollama -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-ollama is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-ollama -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-ollama
      source_release_name: ollama
      chart_ref: ollama-1.56.0
      chart_version: 1.56.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-12-agent-ai-ollama-llama70b
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-ollama-llama70b
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama-llama70b
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-ollama-llama70b.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing --create-namespace
          --version 1.56.0 -f values/values-agent-ai-ollama-llama70b.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing --create-namespace
          --version 1.56.0 -f values/values-agent-ai-ollama-llama70b.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-ollama-llama70b -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-ollama-llama70b is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-ollama-llama70b -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-ollama-llama70b
      source_release_name: ollama-llama70b
      chart_ref: ollama-1.56.0
      chart_version: 1.56.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-13-agent-ai-open-webui
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-open-webui
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:open-webui
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-open-webui.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing --create-namespace
          --version 14.5.0 -f values/values-agent-ai-open-webui.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing --create-namespace
          --version 14.5.0 -f values/values-agent-ai-open-webui.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-open-webui -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-open-webui is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-open-webui -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-open-webui
      source_release_name: open-webui
      chart_ref: open-webui-14.5.0
      chart_version: 14.5.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-14-agent-ai-postgresql
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-postgresql
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:postgresql
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-postgresql.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing --create-namespace
          --version 18.5.6 -f values/values-agent-ai-postgresql.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing --create-namespace
          --version 18.5.6 -f values/values-agent-ai-postgresql.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-postgresql -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-postgresql is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-postgresql -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-postgresql
      source_release_name: postgresql
      chart_ref: postgresql-18.5.6
      chart_version: 18.5.6
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-15-agent-ai-qdrant
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-qdrant
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:qdrant
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-qdrant.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing --create-namespace --version
          1.17.0 -f values/values-agent-ai-qdrant.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing --create-namespace --version
          1.17.0 -f values/values-agent-ai-qdrant.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-qdrant -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-qdrant is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-qdrant -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-qdrant
      source_release_name: qdrant
      chart_ref: qdrant-1.17.0
      chart_version: 1.17.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-16-agent-ai-redis
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-redis
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:redis
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-redis.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-redis redis-25.3.9 --namespace agent-testing --create-namespace --version
          25.3.9 -f values/values-agent-ai-redis.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-redis redis-25.3.9 --namespace agent-testing --create-namespace --version
          25.3.9 -f values/values-agent-ai-redis.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-redis -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-redis is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-redis -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-redis
      source_release_name: redis
      chart_ref: redis-25.3.9
      chart_version: 25.3.9
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: helm-17-agent-ai-supabase
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-supabase
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:supabase
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-supabase.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-supabase supabase-0.5.4 --namespace agent-testing --create-namespace --version
          0.5.4 -f values/values-agent-ai-supabase.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-supabase supabase-0.5.4 --namespace agent-testing --create-namespace --version
          0.5.4 -f values/values-agent-ai-supabase.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-supabase -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-supabase is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-supabase -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-supabase
      source_release_name: supabase
      chart_ref: supabase-0.5.4
      chart_version: 0.5.4
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
  - phase_id: apply_raw_kubernetes_resources
    depends_on:
    - install_helm_releases
    - apply_configmaps
    - apply_pvcs
    objective: Apply supported non-Helm Kubernetes resources in deterministic order.
    steps:
    - step_id: apply_raw_kubernetes_resources-1-deployment-bos-mcp-clickhouse
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bos-mcp-clickhouse
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-clickhouse
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-clickhouse.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bos-mcp-clickhouse -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-clickhouse exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-2-deployment-bos-mcp-mongodb
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bos-mcp-mongodb
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-mongodb
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-mongodb.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bos-mcp-mongodb -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-mongodb exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-3-deployment-bos-mcp-qdrant
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bos-mcp-qdrant
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-qdrant.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bos-mcp-qdrant -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-qdrant exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-4-deployment-bos-mcp-qdrant-docs
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bos-mcp-qdrant-docs
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant-docs
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-qdrant-docs.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bos-mcp-qdrant-docs -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-qdrant-docs exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-5-deployment-bosgenesis-helm-manager-mcp
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bosgenesis-helm-manager-mcp
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-6-deployment-bosgenesis-k8s-inspector-mcp
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bosgenesis-k8s-inspector-mcp
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-7-deployment-bosgenesis-memory-agent-api
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment bosgenesis-memory-agent-api
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-memory-agent-api
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-memory-agent-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment bosgenesis-memory-agent-api -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-memory-agent-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-8-deployment-ch-ui
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment ch-ui
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-ch-ui.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Deployment ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-ch-ui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-9-deployment-dify-api
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment dify-api
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-api
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-dify-api.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-dify-api.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment dify-api -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-dify-api.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-10-deployment-dify-plugin-daemon
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment dify-plugin-daemon
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-plugin-daemon
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-plugin-daemon.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment dify-plugin-daemon -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-plugin-daemon exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-11-deployment-dify-web
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment dify-web
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-web
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-web.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-dify-web.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-dify-web.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment dify-web -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-web exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-dify-web.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-12-deployment-dify-worker
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment dify-worker
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-worker
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-worker.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-dify-worker.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-dify-worker.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment dify-worker -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-worker exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-dify-worker.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-13-deployment-langflow
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment langflow
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:langflow
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-langflow.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-langflow.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-langflow.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment langflow -n agent-testing -o wide
      expected_outcomes:
      - Deployment langflow exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-langflow.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-14-deployment-letta
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment letta
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-letta.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-letta.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment letta -n agent-testing -o wide
      expected_outcomes:
      - Deployment letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-letta.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-15-deployment-redisinsight
      phase_id: apply_raw_kubernetes_resources
      title: Apply Deployment redisinsight
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/deployment-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/deployment-redisinsight.yaml -n agent-testing
      - kind: validate
        command: kubectl get deployment redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Deployment redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/deployment-redisinsight.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-16-service-bos-mcp-clickhouse-svc
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bos-mcp-clickhouse-svc
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-clickhouse-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-clickhouse-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bos-mcp-clickhouse-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-clickhouse-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-17-service-bos-mcp-mongodb-svc
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bos-mcp-mongodb-svc
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-mongodb-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-mongodb-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bos-mcp-mongodb-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-mongodb-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-18-service-bos-mcp-qdrant-docs-svc
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bos-mcp-qdrant-docs-svc
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-docs-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-qdrant-docs-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bos-mcp-qdrant-docs-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-qdrant-docs-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-19-service-bos-mcp-qdrant-svc
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bos-mcp-qdrant-svc
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-qdrant-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bos-mcp-qdrant-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-qdrant-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-20-service-bosgenesis-helm-manager-mcp
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bosgenesis-helm-manager-mcp
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server -o
          yaml
      - kind: apply
        command: kubectl apply -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-21-service-bosgenesis-k8s-inspector-mcp
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bosgenesis-k8s-inspector-mcp
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server -o
          yaml
      - kind: apply
        command: kubectl apply -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-22-service-bosgenesis-memory-agent-api
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service bosgenesis-memory-agent-api
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-memory-agent-api
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-memory-agent-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing --dry-run=server -o
          yaml
      - kind: apply
        command: kubectl apply -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing
      - kind: validate
        command: kubectl get service bosgenesis-memory-agent-api -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-memory-agent-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-23-service-ch-ui
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service ch-ui
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/service-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-ch-ui.yaml -n agent-testing
      - kind: validate
        command: kubectl get service ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Service ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-ch-ui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-24-service-dify-api
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service dify-api
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-api
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-dify-api.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-dify-api.yaml -n agent-testing
      - kind: validate
        command: kubectl get service dify-api -n agent-testing -o wide
      expected_outcomes:
      - Service dify-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-dify-api.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-25-service-dify-plugin-daemon
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service dify-plugin-daemon
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-plugin-daemon
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-plugin-daemon.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-dify-plugin-daemon.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-dify-plugin-daemon.yaml -n agent-testing
      - kind: validate
        command: kubectl get service dify-plugin-daemon -n agent-testing -o wide
      expected_outcomes:
      - Service dify-plugin-daemon exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-26-service-dify-web
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service dify-web
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-web
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-web.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-dify-web.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-dify-web.yaml -n agent-testing
      - kind: validate
        command: kubectl get service dify-web -n agent-testing -o wide
      expected_outcomes:
      - Service dify-web exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-dify-web.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-27-service-langflow
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service langflow
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:langflow
      qdrant_refs: []
      manifest_refs:
      - generated/service-langflow.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-langflow.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-langflow.yaml -n agent-testing
      - kind: validate
        command: kubectl get service langflow -n agent-testing -o wide
      expected_outcomes:
      - Service langflow exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-langflow.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-28-service-letta
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service letta
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/service-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-letta.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-letta.yaml -n agent-testing
      - kind: validate
        command: kubectl get service letta -n agent-testing -o wide
      expected_outcomes:
      - Service letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-letta.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-29-service-mongodb-nodeport
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service mongodb-nodeport
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:mongodb-nodeport
      qdrant_refs: []
      manifest_refs:
      - generated/service-mongodb-nodeport.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-mongodb-nodeport.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-mongodb-nodeport.yaml -n agent-testing
      - kind: validate
        command: kubectl get service mongodb-nodeport -n agent-testing -o wide
      expected_outcomes:
      - Service mongodb-nodeport exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-mongodb-nodeport.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_raw_kubernetes_resources-30-service-redisinsight
      phase_id: apply_raw_kubernetes_resources
      title: Apply Service redisinsight
      type: kubernetes
      depends_on:
      - install_helm_releases
      - apply_configmaps
      - apply_pvcs
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/service-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/service-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/service-redisinsight.yaml -n agent-testing
      - kind: validate
        command: kubectl get service redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Service redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/service-redisinsight.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_ingress
    depends_on:
    - apply_raw_kubernetes_resources
    objective: Apply Ingress resources after backend services are present.
    steps:
    - step_id: apply_ingress-1-ingress-agent-ai-bosgenesis-helm-manager-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-helm-manager-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-2-ingress-agent-ai-bosgenesis-k8s-inspector-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-k8s-inspector-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-3-ingress-agent-ai-ch-ui
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-ch-ui
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-4-ingress-agent-ai-clickhouse-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-clickhouse-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:clickhouse-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-clickhouse-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-clickhouse-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-clickhouse-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-5-ingress-agent-ai-dify
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-dify
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:dify
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-dify.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-dify.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-dify.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-dify -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-dify exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-dify.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-6-ingress-agent-ai-langflow-ingress
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-langflow-ingress
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langflow-ingress
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-langflow-ingress.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-langflow-ingress -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-langflow-ingress exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-7-ingress-agent-ai-langfuse
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-langfuse
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langfuse
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-langfuse.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-langfuse -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-langfuse exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-8-ingress-agent-ai-letta
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-letta
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-letta.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-letta.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-letta -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-letta.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-9-ingress-agent-ai-memory-agent-ingress
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-memory-agent-ingress
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:memory-agent-ingress
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-memory-agent-ingress.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing --dry-run=server -o
          yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-memory-agent-ingress -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-memory-agent-ingress exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-10-ingress-agent-ai-mongodb-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-mongodb-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:mongodb-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-mongodb-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-mongodb-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-mongodb-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-11-ingress-agent-ai-ollama
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-ollama
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ollama.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-ollama.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-ollama.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-ollama -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ollama exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-ollama.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-12-ingress-agent-ai-ollama-llama70b
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-ollama-llama70b
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama-llama70b
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ollama-llama70b.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-ollama-llama70b -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ollama-llama70b exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-13-ingress-agent-ai-open-webui
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-open-webui
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:open-webui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-open-webui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-open-webui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-open-webui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-14-ingress-agent-ai-qdrant
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-qdrant
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-qdrant -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-15-ingress-agent-ai-qdrant-docs-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-qdrant-docs-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-docs-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant-docs-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-qdrant-docs-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant-docs-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-16-ingress-agent-ai-qdrant-mcp
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-qdrant-mcp
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-qdrant-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-17-ingress-agent-ai-redisinsight
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-redisinsight
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-18-ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-data-ingestion-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-19-ingress-agent-ai-bosgenesis-mop-creation-agent
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-mop-creation-agent
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-creation-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-mop-creation-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-mop-creation-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-20-ingress-agent-ai-bosgenesis-mop-execution-agent
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-mop-execution-agent
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-execution-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-mop-execution-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-mop-execution-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-21-ingress-agent-ai-bosgenesis-release-note-agent
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-bosgenesis-release-note-agent
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-release-note-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-bosgenesis-release-note-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-release-note-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-22-ingress-agent-ai-kafka-ui
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-kafka-ui
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:kafka-ui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-kafka-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-kafka-ui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-kafka-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-23-ingress-agent-ai-n8n-main
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-n8n-main
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:n8n-main
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-n8n-main.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-n8n-main -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-n8n-main exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_ingress-24-ingress-agent-ai-supabase-supabase-kong
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-supabase-supabase-kong
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:supabase-supabase-kong
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-supabase-supabase-kong.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing --dry-run=server
          -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-supabase-supabase-kong -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-supabase-supabase-kong exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_application_metadata
    depends_on:
    - apply_raw_kubernetes_resources
    objective: Application-mode metadata recreation is deferred until application evidence exists.
    steps: []
    enabled_when: generation_mode == "application"
  - phase_id: validate
    depends_on:
    - apply_ingress
    - apply_application_metadata
    objective: Confirm generated resources are visible and healthy in the target namespace.
    steps:
    - step_id: validate-preflight-1
      phase_id: validate
      title: Run validation command 1
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: validate
        command: kubectl get all,configmap,pvc,ingress -n agent-testing
      expected_outcomes:
      - Command succeeds and expected resources are visible.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-preflight-2
      phase_id: validate
      title: Run validation command 2
      type: context_check
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: validate
        command: helm list -n agent-testing
      expected_outcomes:
      - Command succeeds and expected resources are visible.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-helm-1-agent-ai-bosgenesis-k8s-data-ingestion-agent
      phase_id: validate
      title: Validate Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-k8s-data-ingestion-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0 --namespace
          agent-testing -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml --version 0.1.0
      - kind: helm_status
        command: helm status agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing
      expected_outcomes:
      - Helm chart bosgenesis-k8s-data-ingestion-agent-0.1.0 renders for release agent-ai-bosgenesis-k8s-data-ingestion-agent.
      - Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-k8s-data-ingestion-agent
      source_release_name: bosgenesis-k8s-data-ingestion-agent
      chart_ref: bosgenesis-k8s-data-ingestion-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-2-agent-ai-bosgenesis-mop-creation-agent
      phase_id: validate
      title: Validate Helm release agent-ai-bosgenesis-mop-creation-agent
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-creation-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-mop-creation-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace agent-testing
          -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --version 0.1.0
      - kind: helm_status
        command: helm status agent-ai-bosgenesis-mop-creation-agent -n agent-testing
      expected_outcomes:
      - Helm chart bosgenesis-mop-creation-agent-0.1.0 renders for release agent-ai-bosgenesis-mop-creation-agent.
      - Helm release agent-ai-bosgenesis-mop-creation-agent is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-mop-creation-agent
      source_release_name: bosgenesis-mop-creation-agent
      chart_ref: bosgenesis-mop-creation-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-3-agent-ai-bosgenesis-mop-execution-agent
      phase_id: validate
      title: Validate Helm release agent-ai-bosgenesis-mop-execution-agent
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-execution-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-mop-execution-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace agent-testing
          -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --version 0.1.0
      - kind: helm_status
        command: helm status agent-ai-bosgenesis-mop-execution-agent -n agent-testing
      expected_outcomes:
      - Helm chart bosgenesis-mop-execution-agent-0.1.0 renders for release agent-ai-bosgenesis-mop-execution-agent.
      - Helm release agent-ai-bosgenesis-mop-execution-agent is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-mop-execution-agent
      source_release_name: bosgenesis-mop-execution-agent
      chart_ref: bosgenesis-mop-execution-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-4-agent-ai-bosgenesis-release-note-agent
      phase_id: validate
      title: Validate Helm release agent-ai-bosgenesis-release-note-agent
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-release-note-agent
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-bosgenesis-release-note-agent.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace agent-testing
          -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --version 0.1.0
      - kind: helm_status
        command: helm status agent-ai-bosgenesis-release-note-agent -n agent-testing
      expected_outcomes:
      - Helm chart bosgenesis-release-note-agent-0.1.0 renders for release agent-ai-bosgenesis-release-note-agent.
      - Helm release agent-ai-bosgenesis-release-note-agent is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-bosgenesis-release-note-agent
      source_release_name: bosgenesis-release-note-agent
      chart_ref: bosgenesis-release-note-agent-0.1.0
      chart_version: 0.1.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-5-agent-ai-clickhouse
      phase_id: validate
      title: Validate Helm release agent-ai-clickhouse
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:clickhouse
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-clickhouse.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing -f values/values-agent-ai-clickhouse.yaml
          --version 9.4.4
      - kind: helm_status
        command: helm status agent-ai-clickhouse -n agent-testing
      expected_outcomes:
      - Helm chart clickhouse-9.4.4 renders for release agent-ai-clickhouse.
      - Helm release agent-ai-clickhouse is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-clickhouse
      source_release_name: clickhouse
      chart_ref: clickhouse-9.4.4
      chart_version: 9.4.4
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-6-agent-ai-kafka
      phase_id: validate
      title: Validate Helm release agent-ai-kafka
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-kafka.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-kafka kafka-32.4.3 --namespace agent-testing -f values/values-agent-ai-kafka.yaml
          --version 32.4.3
      - kind: helm_status
        command: helm status agent-ai-kafka -n agent-testing
      expected_outcomes:
      - Helm chart kafka-32.4.3 renders for release agent-ai-kafka.
      - Helm release agent-ai-kafka is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-kafka
      source_release_name: kafka
      chart_ref: kafka-32.4.3
      chart_version: 32.4.3
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-7-agent-ai-kafka-ui
      phase_id: validate
      title: Validate Helm release agent-ai-kafka-ui
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka-ui
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-kafka-ui.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing -f values/values-agent-ai-kafka-ui.yaml
          --version 0.7.6
      - kind: helm_status
        command: helm status agent-ai-kafka-ui -n agent-testing
      expected_outcomes:
      - Helm chart kafka-ui-0.7.6 renders for release agent-ai-kafka-ui.
      - Helm release agent-ai-kafka-ui is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-kafka-ui
      source_release_name: kafka-ui
      chart_ref: kafka-ui-0.7.6
      chart_version: 0.7.6
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-8-agent-ai-langfuse
      phase_id: validate
      title: Validate Helm release agent-ai-langfuse
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:langfuse
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-langfuse.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing -f values/values-agent-ai-langfuse.yaml
          --version 1.5.29
      - kind: helm_status
        command: helm status agent-ai-langfuse -n agent-testing
      expected_outcomes:
      - Helm chart langfuse-1.5.29 renders for release agent-ai-langfuse.
      - Helm release agent-ai-langfuse is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-langfuse
      source_release_name: langfuse
      chart_ref: langfuse-1.5.29
      chart_version: 1.5.29
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-9-agent-ai-mongodb
      phase_id: validate
      title: Validate Helm release agent-ai-mongodb
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:mongodb
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-mongodb.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing -f values/values-agent-ai-mongodb.yaml
          --version 18.6.21
      - kind: helm_status
        command: helm status agent-ai-mongodb -n agent-testing
      expected_outcomes:
      - Helm chart mongodb-18.6.21 renders for release agent-ai-mongodb.
      - Helm release agent-ai-mongodb is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-mongodb
      source_release_name: mongodb
      chart_ref: mongodb-18.6.21
      chart_version: 18.6.21
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-10-agent-ai-n8n
      phase_id: validate
      title: Validate Helm release agent-ai-n8n
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:n8n
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-n8n.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-n8n n8n-1.0.0 --namespace agent-testing -f values/values-agent-ai-n8n.yaml --version
          1.0.0
      - kind: helm_status
        command: helm status agent-ai-n8n -n agent-testing
      expected_outcomes:
      - Helm chart n8n-1.0.0 renders for release agent-ai-n8n.
      - Helm release agent-ai-n8n is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-n8n
      source_release_name: n8n
      chart_ref: n8n-1.0.0
      chart_version: 1.0.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-11-agent-ai-ollama
      phase_id: validate
      title: Validate Helm release agent-ai-ollama
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-ollama.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-ollama ollama-1.56.0 --namespace agent-testing -f values/values-agent-ai-ollama.yaml
          --version 1.56.0
      - kind: helm_status
        command: helm status agent-ai-ollama -n agent-testing
      expected_outcomes:
      - Helm chart ollama-1.56.0 renders for release agent-ai-ollama.
      - Helm release agent-ai-ollama is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-ollama
      source_release_name: ollama
      chart_ref: ollama-1.56.0
      chart_version: 1.56.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-12-agent-ai-ollama-llama70b
      phase_id: validate
      title: Validate Helm release agent-ai-ollama-llama70b
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama-llama70b
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-ollama-llama70b.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing -f values/values-agent-ai-ollama-llama70b.yaml
          --version 1.56.0
      - kind: helm_status
        command: helm status agent-ai-ollama-llama70b -n agent-testing
      expected_outcomes:
      - Helm chart ollama-1.56.0 renders for release agent-ai-ollama-llama70b.
      - Helm release agent-ai-ollama-llama70b is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-ollama-llama70b
      source_release_name: ollama-llama70b
      chart_ref: ollama-1.56.0
      chart_version: 1.56.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-13-agent-ai-open-webui
      phase_id: validate
      title: Validate Helm release agent-ai-open-webui
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:open-webui
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-open-webui.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing -f values/values-agent-ai-open-webui.yaml
          --version 14.5.0
      - kind: helm_status
        command: helm status agent-ai-open-webui -n agent-testing
      expected_outcomes:
      - Helm chart open-webui-14.5.0 renders for release agent-ai-open-webui.
      - Helm release agent-ai-open-webui is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-open-webui
      source_release_name: open-webui
      chart_ref: open-webui-14.5.0
      chart_version: 14.5.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-14-agent-ai-postgresql
      phase_id: validate
      title: Validate Helm release agent-ai-postgresql
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:postgresql
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-postgresql.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing -f values/values-agent-ai-postgresql.yaml
          --version 18.5.6
      - kind: helm_status
        command: helm status agent-ai-postgresql -n agent-testing
      expected_outcomes:
      - Helm chart postgresql-18.5.6 renders for release agent-ai-postgresql.
      - Helm release agent-ai-postgresql is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-postgresql
      source_release_name: postgresql
      chart_ref: postgresql-18.5.6
      chart_version: 18.5.6
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-15-agent-ai-qdrant
      phase_id: validate
      title: Validate Helm release agent-ai-qdrant
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:qdrant
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-qdrant.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing -f values/values-agent-ai-qdrant.yaml
          --version 1.17.0
      - kind: helm_status
        command: helm status agent-ai-qdrant -n agent-testing
      expected_outcomes:
      - Helm chart qdrant-1.17.0 renders for release agent-ai-qdrant.
      - Helm release agent-ai-qdrant is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-qdrant
      source_release_name: qdrant
      chart_ref: qdrant-1.17.0
      chart_version: 1.17.0
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-16-agent-ai-redis
      phase_id: validate
      title: Validate Helm release agent-ai-redis
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:redis
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-redis.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-redis redis-25.3.9 --namespace agent-testing -f values/values-agent-ai-redis.yaml
          --version 25.3.9
      - kind: helm_status
        command: helm status agent-ai-redis -n agent-testing
      expected_outcomes:
      - Helm chart redis-25.3.9 renders for release agent-ai-redis.
      - Helm release agent-ai-redis is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-redis
      source_release_name: redis
      chart_ref: redis-25.3.9
      chart_version: 25.3.9
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-helm-17-agent-ai-supabase
      phase_id: validate
      title: Validate Helm release agent-ai-supabase
      type: helm_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:supabase
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-supabase.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as operator evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-supabase supabase-0.5.4 --namespace agent-testing -f values/values-agent-ai-supabase.yaml
          --version 0.5.4
      - kind: helm_status
        command: helm status agent-ai-supabase -n agent-testing
      expected_outcomes:
      - Helm chart supabase-0.5.4 renders for release agent-ai-supabase.
      - Helm release agent-ai-supabase is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-supabase
      source_release_name: supabase
      chart_ref: supabase-0.5.4
      chart_version: 0.5.4
      chart_source: unknown
      repo_name: null
      repo_url: null
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-k8s-1-configmap-bosgenesis-helm-manager-mcp-config
      phase_id: validate
      title: Validate ConfigMap bosgenesis-helm-manager-mcp-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-helm-manager-mcp-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-bosgenesis-helm-manager-mcp-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap bosgenesis-helm-manager-mcp-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap bosgenesis-helm-manager-mcp-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-2-configmap-bosgenesis-k8s-inspector-mcp-config
      phase_id: validate
      title: Validate ConfigMap bosgenesis-k8s-inspector-mcp-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-k8s-inspector-mcp-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap bosgenesis-k8s-inspector-mcp-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap bosgenesis-k8s-inspector-mcp-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-3-configmap-dify-config
      phase_id: validate
      title: Validate ConfigMap dify-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:dify-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-dify-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap dify-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap dify-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-4-configmap-istio-ca-crl
      phase_id: validate
      title: Validate ConfigMap istio-ca-crl
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-crl
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-crl.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap istio-ca-crl -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-crl exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-5-configmap-istio-ca-root-cert
      phase_id: validate
      title: Validate ConfigMap istio-ca-root-cert
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-root-cert
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-root-cert.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-root-cert exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-6-configmap-kube-root-ca.crt
      phase_id: validate
      title: Validate ConfigMap kube-root-ca.crt
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:kube-root-ca.crt
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-kube-root-ca.crt.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap kube-root-ca.crt exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-7-configmap-langflow-config
      phase_id: validate
      title: Validate ConfigMap langflow-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:langflow-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-langflow-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap langflow-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap langflow-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-8-configmap-letta-config
      phase_id: validate
      title: Validate ConfigMap letta-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:letta-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-letta-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap letta-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap letta-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-9-configmap-memory-agent-config
      phase_id: validate
      title: Validate ConfigMap memory-agent-config
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:memory-agent-config
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-memory-agent-config.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap memory-agent-config -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap memory-agent-config exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-10-deployment-bos-mcp-clickhouse
      phase_id: validate
      title: Validate Deployment bos-mcp-clickhouse
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-clickhouse
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-clickhouse.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bos-mcp-clickhouse -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-clickhouse exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-11-deployment-bos-mcp-mongodb
      phase_id: validate
      title: Validate Deployment bos-mcp-mongodb
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-mongodb
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-mongodb.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bos-mcp-mongodb -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-mongodb exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-12-deployment-bos-mcp-qdrant
      phase_id: validate
      title: Validate Deployment bos-mcp-qdrant
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-qdrant.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bos-mcp-qdrant -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-qdrant exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-13-deployment-bos-mcp-qdrant-docs
      phase_id: validate
      title: Validate Deployment bos-mcp-qdrant-docs
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant-docs
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bos-mcp-qdrant-docs.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bos-mcp-qdrant-docs -n agent-testing -o wide
      expected_outcomes:
      - Deployment bos-mcp-qdrant-docs exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-14-deployment-bosgenesis-helm-manager-mcp
      phase_id: validate
      title: Validate Deployment bosgenesis-helm-manager-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-15-deployment-bosgenesis-k8s-inspector-mcp
      phase_id: validate
      title: Validate Deployment bosgenesis-k8s-inspector-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-16-deployment-bosgenesis-memory-agent-api
      phase_id: validate
      title: Validate Deployment bosgenesis-memory-agent-api
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-memory-agent-api
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-bosgenesis-memory-agent-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment bosgenesis-memory-agent-api -n agent-testing -o wide
      expected_outcomes:
      - Deployment bosgenesis-memory-agent-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-17-deployment-ch-ui
      phase_id: validate
      title: Validate Deployment ch-ui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Deployment ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-18-deployment-dify-api
      phase_id: validate
      title: Validate Deployment dify-api
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-api
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment dify-api -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-19-deployment-dify-plugin-daemon
      phase_id: validate
      title: Validate Deployment dify-plugin-daemon
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-plugin-daemon
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-plugin-daemon.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment dify-plugin-daemon -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-plugin-daemon exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-20-deployment-dify-web
      phase_id: validate
      title: Validate Deployment dify-web
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-web
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-web.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment dify-web -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-web exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-21-deployment-dify-worker
      phase_id: validate
      title: Validate Deployment dify-worker
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-worker
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-dify-worker.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment dify-worker -n agent-testing -o wide
      expected_outcomes:
      - Deployment dify-worker exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-22-deployment-langflow
      phase_id: validate
      title: Validate Deployment langflow
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:langflow
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-langflow.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment langflow -n agent-testing -o wide
      expected_outcomes:
      - Deployment langflow exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-23-deployment-letta
      phase_id: validate
      title: Validate Deployment letta
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment letta -n agent-testing -o wide
      expected_outcomes:
      - Deployment letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-24-deployment-redisinsight
      phase_id: validate
      title: Validate Deployment redisinsight
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/deployment-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get deployment redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Deployment redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-25-ingress-agent-ai-bosgenesis-helm-manager-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-helm-manager-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-26-ingress-agent-ai-bosgenesis-k8s-inspector-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-k8s-inspector-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-27-ingress-agent-ai-ch-ui
      phase_id: validate
      title: Validate Ingress agent-ai-ch-ui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-28-ingress-agent-ai-clickhouse-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-clickhouse-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:clickhouse-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-clickhouse-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-clickhouse-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-clickhouse-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-29-ingress-agent-ai-dify
      phase_id: validate
      title: Validate Ingress agent-ai-dify
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:dify
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-dify.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-dify -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-dify exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-30-ingress-agent-ai-langflow-ingress
      phase_id: validate
      title: Validate Ingress agent-ai-langflow-ingress
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langflow-ingress
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-langflow-ingress.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-langflow-ingress -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-langflow-ingress exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-31-ingress-agent-ai-langfuse
      phase_id: validate
      title: Validate Ingress agent-ai-langfuse
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langfuse
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-langfuse.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-langfuse -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-langfuse exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-32-ingress-agent-ai-letta
      phase_id: validate
      title: Validate Ingress agent-ai-letta
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-letta -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-33-ingress-agent-ai-memory-agent-ingress
      phase_id: validate
      title: Validate Ingress agent-ai-memory-agent-ingress
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:memory-agent-ingress
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-memory-agent-ingress.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-memory-agent-ingress -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-memory-agent-ingress exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-34-ingress-agent-ai-mongodb-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-mongodb-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:mongodb-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-mongodb-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-mongodb-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-mongodb-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-35-ingress-agent-ai-ollama
      phase_id: validate
      title: Validate Ingress agent-ai-ollama
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ollama.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-ollama -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ollama exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-36-ingress-agent-ai-ollama-llama70b
      phase_id: validate
      title: Validate Ingress agent-ai-ollama-llama70b
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama-llama70b
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-ollama-llama70b.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-ollama-llama70b -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-ollama-llama70b exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-37-ingress-agent-ai-open-webui
      phase_id: validate
      title: Validate Ingress agent-ai-open-webui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:open-webui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-open-webui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-open-webui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-open-webui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-38-ingress-agent-ai-qdrant
      phase_id: validate
      title: Validate Ingress agent-ai-qdrant
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-qdrant -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-39-ingress-agent-ai-qdrant-docs-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-qdrant-docs-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-docs-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant-docs-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-qdrant-docs-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant-docs-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-40-ingress-agent-ai-qdrant-mcp
      phase_id: validate
      title: Validate Ingress agent-ai-qdrant-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-qdrant-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-qdrant-mcp -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-qdrant-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-41-ingress-agent-ai-redisinsight
      phase_id: validate
      title: Validate Ingress agent-ai-redisinsight
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-42-persistentvolumeclaim-ch-ui
      phase_id: validate
      title: Validate PersistentVolumeClaim ch-ui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim ch-ui -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-43-persistentvolumeclaim-dify-storage
      phase_id: validate
      title: Validate PersistentVolumeClaim dify-storage
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:dify-storage
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-dify-storage.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim dify-storage -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim dify-storage exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-44-persistentvolumeclaim-langflow-pvc
      phase_id: validate
      title: Validate PersistentVolumeClaim langflow-pvc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:langflow-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-langflow-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim langflow-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim langflow-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-45-persistentvolumeclaim-memory-agent-lancedb-pvc
      phase_id: validate
      title: Validate PersistentVolumeClaim memory-agent-lancedb-pvc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:memory-agent-lancedb-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim memory-agent-lancedb-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim memory-agent-lancedb-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-46-persistentvolumeclaim-ollama
      phase_id: validate
      title: Validate PersistentVolumeClaim ollama
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ollama
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-ollama.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim ollama -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim ollama exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-47-persistentvolumeclaim-redisinsight-pvc
      phase_id: validate
      title: Validate PersistentVolumeClaim redisinsight-pvc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:redisinsight-pvc
      qdrant_refs: []
      manifest_refs:
      - generated/persistentvolumeclaim-redisinsight-pvc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get persistentvolumeclaim redisinsight-pvc -n agent-testing -o wide
      expected_outcomes:
      - PersistentVolumeClaim redisinsight-pvc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-48-service-bos-mcp-clickhouse-svc
      phase_id: validate
      title: Validate Service bos-mcp-clickhouse-svc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-clickhouse-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-clickhouse-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bos-mcp-clickhouse-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-clickhouse-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-49-service-bos-mcp-mongodb-svc
      phase_id: validate
      title: Validate Service bos-mcp-mongodb-svc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-mongodb-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-mongodb-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bos-mcp-mongodb-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-mongodb-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-50-service-bos-mcp-qdrant-docs-svc
      phase_id: validate
      title: Validate Service bos-mcp-qdrant-docs-svc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-docs-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-qdrant-docs-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bos-mcp-qdrant-docs-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-qdrant-docs-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-51-service-bos-mcp-qdrant-svc
      phase_id: validate
      title: Validate Service bos-mcp-qdrant-svc
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-svc
      qdrant_refs: []
      manifest_refs:
      - generated/service-bos-mcp-qdrant-svc.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bos-mcp-qdrant-svc -n agent-testing -o wide
      expected_outcomes:
      - Service bos-mcp-qdrant-svc exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-52-service-bosgenesis-helm-manager-mcp
      phase_id: validate
      title: Validate Service bosgenesis-helm-manager-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-helm-manager-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-helm-manager-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bosgenesis-helm-manager-mcp -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-helm-manager-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-53-service-bosgenesis-k8s-inspector-mcp
      phase_id: validate
      title: Validate Service bosgenesis-k8s-inspector-mcp
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-k8s-inspector-mcp
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-k8s-inspector-mcp.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-54-service-bosgenesis-memory-agent-api
      phase_id: validate
      title: Validate Service bosgenesis-memory-agent-api
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-memory-agent-api
      qdrant_refs: []
      manifest_refs:
      - generated/service-bosgenesis-memory-agent-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service bosgenesis-memory-agent-api -n agent-testing -o wide
      expected_outcomes:
      - Service bosgenesis-memory-agent-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-55-service-ch-ui
      phase_id: validate
      title: Validate Service ch-ui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:ch-ui
      qdrant_refs: []
      manifest_refs:
      - generated/service-ch-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service ch-ui -n agent-testing -o wide
      expected_outcomes:
      - Service ch-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-56-service-dify-api
      phase_id: validate
      title: Validate Service dify-api
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-api
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-api.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service dify-api -n agent-testing -o wide
      expected_outcomes:
      - Service dify-api exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-57-service-dify-plugin-daemon
      phase_id: validate
      title: Validate Service dify-plugin-daemon
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-plugin-daemon
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-plugin-daemon.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service dify-plugin-daemon -n agent-testing -o wide
      expected_outcomes:
      - Service dify-plugin-daemon exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-58-service-dify-web
      phase_id: validate
      title: Validate Service dify-web
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-web
      qdrant_refs: []
      manifest_refs:
      - generated/service-dify-web.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service dify-web -n agent-testing -o wide
      expected_outcomes:
      - Service dify-web exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-59-service-langflow
      phase_id: validate
      title: Validate Service langflow
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:langflow
      qdrant_refs: []
      manifest_refs:
      - generated/service-langflow.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service langflow -n agent-testing -o wide
      expected_outcomes:
      - Service langflow exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-60-service-letta
      phase_id: validate
      title: Validate Service letta
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:letta
      qdrant_refs: []
      manifest_refs:
      - generated/service-letta.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service letta -n agent-testing -o wide
      expected_outcomes:
      - Service letta exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-61-service-mongodb-nodeport
      phase_id: validate
      title: Validate Service mongodb-nodeport
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:mongodb-nodeport
      qdrant_refs: []
      manifest_refs:
      - generated/service-mongodb-nodeport.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service mongodb-nodeport -n agent-testing -o wide
      expected_outcomes:
      - Service mongodb-nodeport exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-62-service-redisinsight
      phase_id: validate
      title: Validate Service redisinsight
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:redisinsight
      qdrant_refs: []
      manifest_refs:
      - generated/service-redisinsight.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get service redisinsight -n agent-testing -o wide
      expected_outcomes:
      - Service redisinsight exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-63-ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-data-ingestion-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-64-ingress-agent-ai-bosgenesis-mop-creation-agent
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-mop-creation-agent
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-creation-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-mop-creation-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-mop-creation-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-65-ingress-agent-ai-bosgenesis-mop-execution-agent
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-mop-execution-agent
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-execution-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-mop-execution-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-mop-execution-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-66-ingress-agent-ai-bosgenesis-release-note-agent
      phase_id: validate
      title: Validate Ingress agent-ai-bosgenesis-release-note-agent
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-release-note-agent
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-bosgenesis-release-note-agent -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-bosgenesis-release-note-agent exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-67-ingress-agent-ai-kafka-ui
      phase_id: validate
      title: Validate Ingress agent-ai-kafka-ui
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:kafka-ui
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-kafka-ui.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-kafka-ui -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-kafka-ui exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-68-ingress-agent-ai-n8n-main
      phase_id: validate
      title: Validate Ingress agent-ai-n8n-main
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:n8n-main
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-n8n-main.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-n8n-main -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-n8n-main exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-69-ingress-agent-ai-supabase-supabase-kong
      phase_id: validate
      title: Validate Ingress agent-ai-supabase-supabase-kong
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:supabase-supabase-kong
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-supabase-supabase-kong.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-supabase-supabase-kong -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-supabase-supabase-kong exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
```

## 8. Execution Phases

Each command-bearing step inside a phase must use this shape:

```yaml
step:
  step_id: "<stable-phase-local-id>"
  title: "<short action title>"
  type: "context_check | namespace | secret_placeholder | configmap | pvc | helm | kubernetes | ingress | application_metadata | validation | rollback"
  depends_on: []
  evidence_refs: []
  qdrant_refs: []
  inference:
    label: "observed | inferred | prior_reference | human_input_required"
    confidence: "high | medium | low"
    rationale: "<why this step exists>"
  command: |
    <copyable command or human-action placeholder>
  expected: "<expected state or output>"
  on_failure: "<STOP, investigate, or rollback instruction>"
  mutates_target: true
  requires_human_approval: true
```

### Phase 1 - Verify Access

```yaml
phase_id: verify_access
objective: Confirm source/target context, namespace visibility, and tool availability.
commands:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - Snapshot and MCP inventory evidence is represented in generated artifacts.
stop_conditions:
  - Local artifact directory is not writable.
evidence_refs:
  - artifact.json
```

### Phase 2 - Prepare Target Namespace

```yaml
phase_id: prepare_target_namespace
objective: Ensure target namespace exists before applying namespaced resources.
commands:
  - step_id: prepare-target-namespace
    title: Ensure target namespace exists
    type: namespace
    depends_on: [verify_access]
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: high
      rationale: Target namespace is supplied by the generation request.
    command: |
      kubectl get namespace agent-testing || kubectl create namespace agent-testing
      kubectl get namespace agent-testing
    expected: Namespace agent-testing exists.
    on_failure: STOP and confirm namespace creation is approved.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Namespace agent-testing exists.
rollback:
  - Delete the target namespace only if it was created for this change and cleanup is approved.
evidence_refs:
  - artifact.json
```

### Phase 3 - Prepare Secret Placeholders

```yaml
phase_id: prepare_secret_placeholders
objective: Ensure required secret names and keys exist using approved secure values.
manual_inputs:
  []
commands:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - No secrets are generated or copied.
stop_conditions:
  - Missing approved secret material.
  - Any generated content contains secret values.
evidence_refs:
  - artifact.json
```

### Phase 4 - Apply ConfigMaps

```yaml
phase_id: apply_configmaps
objective: Apply generated ConfigMap manifests after namespace rewrite and redaction.
commands:
  - step_id: raw-1-configmap-bosgenesis-helm-manager-mcp-config
    title: Apply ConfigMap bosgenesis-helm-manager-mcp-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-bosgenesis-helm-manager-mcp-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-helm-manager-mcp-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing
    expected: ConfigMap bosgenesis-helm-manager-mcp-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-2-configmap-bosgenesis-k8s-inspector-mcp-config
    title: Apply ConfigMap bosgenesis-k8s-inspector-mcp-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-k8s-inspector-mcp-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing
    expected: ConfigMap bosgenesis-k8s-inspector-mcp-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-3-configmap-dify-config
    title: Apply ConfigMap dify-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-dify-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:dify-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-dify-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-dify-config.yaml -n agent-testing
    expected: ConfigMap dify-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-4-configmap-istio-ca-crl
    title: Apply ConfigMap istio-ca-crl
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-crl.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-crl]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing
    expected: ConfigMap istio-ca-crl exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-5-configmap-istio-ca-root-cert
    title: Apply ConfigMap istio-ca-root-cert
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-root-cert.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-root-cert]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing
    expected: ConfigMap istio-ca-root-cert exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-6-configmap-kube-root-ca.crt
    title: Apply ConfigMap kube-root-ca.crt
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-kube-root-ca.crt.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:kube-root-ca.crt]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing
    expected: ConfigMap kube-root-ca.crt exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-7-configmap-langflow-config
    title: Apply ConfigMap langflow-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-langflow-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:langflow-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-langflow-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-langflow-config.yaml -n agent-testing
    expected: ConfigMap langflow-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-8-configmap-letta-config
    title: Apply ConfigMap letta-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-letta-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:letta-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-letta-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-letta-config.yaml -n agent-testing
    expected: ConfigMap letta-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-9-configmap-memory-agent-config
    title: Apply ConfigMap memory-agent-config
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-memory-agent-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:memory-agent-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-memory-agent-config.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-memory-agent-config.yaml -n agent-testing
    expected: ConfigMap memory-agent-config exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - ConfigMaps are accepted by dry-run and then applied when approved.
rollback:
  - kubectl delete -f generated/configmap-memory-agent-config.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-letta-config.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-langflow-config.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-istio-ca-crl.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-dify-config.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-bosgenesis-helm-manager-mcp-config.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 5 - Apply PVCs

```yaml
phase_id: apply_pvcs
objective: Create approved PVCs when storage class and capacity are confirmed.
commands:
  - step_id: raw-1-persistentvolumeclaim-ch-ui
    title: Apply PersistentVolumeClaim ch-ui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing
    expected: PersistentVolumeClaim ch-ui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-2-persistentvolumeclaim-dify-storage
    title: Apply PersistentVolumeClaim dify-storage
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-dify-storage.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:dify-storage]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing
    expected: PersistentVolumeClaim dify-storage exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-3-persistentvolumeclaim-langflow-pvc
    title: Apply PersistentVolumeClaim langflow-pvc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-langflow-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:langflow-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing
    expected: PersistentVolumeClaim langflow-pvc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-4-persistentvolumeclaim-memory-agent-lancedb-pvc
    title: Apply PersistentVolumeClaim memory-agent-lancedb-pvc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:memory-agent-lancedb-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing
    expected: PersistentVolumeClaim memory-agent-lancedb-pvc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-5-persistentvolumeclaim-ollama
    title: Apply PersistentVolumeClaim ollama
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-ollama.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ollama]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing
    expected: PersistentVolumeClaim ollama exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-6-persistentvolumeclaim-redisinsight-pvc
    title: Apply PersistentVolumeClaim redisinsight-pvc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-redisinsight-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:redisinsight-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing
    expected: PersistentVolumeClaim redisinsight-pvc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - PVCs are accepted by dry-run and then applied when approved.
rollback:
  - kubectl delete -f generated/persistentvolumeclaim-redisinsight-pvc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/persistentvolumeclaim-ollama.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/persistentvolumeclaim-langflow-pvc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/persistentvolumeclaim-dify-storage.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/persistentvolumeclaim-ch-ui.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 6 - Install Helm Releases

```yaml
phase_id: install_helm_releases
objective: Recreate Helm-managed components using generated values files.
step_contract:
  dry_run_required: true
  real_install_requires_successful_dry_run: true
  chart_sources_must_be_public: true
commands:
  - step_id: helm-1-agent-ai-bosgenesis-k8s-data-ingestion-agent
    title: Install Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent
    type: helm_upgrade
    release_name: agent-ai-bosgenesis-k8s-data-ingestion-agent
    source_release_name: bosgenesis-k8s-data-ingestion-agent
    chart_source: unknown
    chart_ref: bosgenesis-k8s-data-ingestion-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-k8s-data-ingestion-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml --dry-run
      helm upgrade --install agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-2-agent-ai-bosgenesis-mop-creation-agent
    title: Install Helm release agent-ai-bosgenesis-mop-creation-agent
    type: helm_upgrade
    release_name: agent-ai-bosgenesis-mop-creation-agent
    source_release_name: bosgenesis-mop-creation-agent
    chart_source: unknown
    chart_ref: bosgenesis-mop-creation-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-mop-creation-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-creation-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --dry-run
      helm upgrade --install agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-bosgenesis-mop-creation-agent is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-3-agent-ai-bosgenesis-mop-execution-agent
    title: Install Helm release agent-ai-bosgenesis-mop-execution-agent
    type: helm_upgrade
    release_name: agent-ai-bosgenesis-mop-execution-agent
    source_release_name: bosgenesis-mop-execution-agent
    chart_source: unknown
    chart_ref: bosgenesis-mop-execution-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-mop-execution-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-execution-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --dry-run
      helm upgrade --install agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-bosgenesis-mop-execution-agent is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-4-agent-ai-bosgenesis-release-note-agent
    title: Install Helm release agent-ai-bosgenesis-release-note-agent
    type: helm_upgrade
    release_name: agent-ai-bosgenesis-release-note-agent
    source_release_name: bosgenesis-release-note-agent
    chart_source: unknown
    chart_ref: bosgenesis-release-note-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-release-note-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-release-note-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --dry-run
      helm upgrade --install agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace agent-testing --create-namespace --version 0.1.0 -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-bosgenesis-release-note-agent is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-5-agent-ai-clickhouse
    title: Install Helm release agent-ai-clickhouse
    type: helm_upgrade
    release_name: agent-ai-clickhouse
    source_release_name: clickhouse
    chart_source: unknown
    chart_ref: clickhouse-9.4.4
    chart_version: 9.4.4
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-clickhouse.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:clickhouse]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing --create-namespace --version 9.4.4 -f values/values-agent-ai-clickhouse.yaml --dry-run
      helm upgrade --install agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing --create-namespace --version 9.4.4 -f values/values-agent-ai-clickhouse.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-clickhouse is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-6-agent-ai-kafka
    title: Install Helm release agent-ai-kafka
    type: helm_upgrade
    release_name: agent-ai-kafka
    source_release_name: kafka
    chart_source: unknown
    chart_ref: kafka-32.4.3
    chart_version: 32.4.3
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-kafka.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-kafka kafka-32.4.3 --namespace agent-testing --create-namespace --version 32.4.3 -f values/values-agent-ai-kafka.yaml --dry-run
      helm upgrade --install agent-ai-kafka kafka-32.4.3 --namespace agent-testing --create-namespace --version 32.4.3 -f values/values-agent-ai-kafka.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-kafka is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-7-agent-ai-kafka-ui
    title: Install Helm release agent-ai-kafka-ui
    type: helm_upgrade
    release_name: agent-ai-kafka-ui
    source_release_name: kafka-ui
    chart_source: unknown
    chart_ref: kafka-ui-0.7.6
    chart_version: 0.7.6
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-kafka-ui.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka-ui]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing --create-namespace --version 0.7.6 -f values/values-agent-ai-kafka-ui.yaml --dry-run
      helm upgrade --install agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing --create-namespace --version 0.7.6 -f values/values-agent-ai-kafka-ui.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-kafka-ui is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-8-agent-ai-langfuse
    title: Install Helm release agent-ai-langfuse
    type: helm_upgrade
    release_name: agent-ai-langfuse
    source_release_name: langfuse
    chart_source: unknown
    chart_ref: langfuse-1.5.29
    chart_version: 1.5.29
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-langfuse.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:langfuse]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing --create-namespace --version 1.5.29 -f values/values-agent-ai-langfuse.yaml --dry-run
      helm upgrade --install agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing --create-namespace --version 1.5.29 -f values/values-agent-ai-langfuse.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-langfuse is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-9-agent-ai-mongodb
    title: Install Helm release agent-ai-mongodb
    type: helm_upgrade
    release_name: agent-ai-mongodb
    source_release_name: mongodb
    chart_source: unknown
    chart_ref: mongodb-18.6.21
    chart_version: 18.6.21
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-mongodb.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:mongodb]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing --create-namespace --version 18.6.21 -f values/values-agent-ai-mongodb.yaml --dry-run
      helm upgrade --install agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing --create-namespace --version 18.6.21 -f values/values-agent-ai-mongodb.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-mongodb is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-10-agent-ai-n8n
    title: Install Helm release agent-ai-n8n
    type: helm_upgrade
    release_name: agent-ai-n8n
    source_release_name: n8n
    chart_source: unknown
    chart_ref: n8n-1.0.0
    chart_version: 1.0.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-n8n.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:n8n]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-n8n n8n-1.0.0 --namespace agent-testing --create-namespace --version 1.0.0 -f values/values-agent-ai-n8n.yaml --dry-run
      helm upgrade --install agent-ai-n8n n8n-1.0.0 --namespace agent-testing --create-namespace --version 1.0.0 -f values/values-agent-ai-n8n.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-n8n is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-11-agent-ai-ollama
    title: Install Helm release agent-ai-ollama
    type: helm_upgrade
    release_name: agent-ai-ollama
    source_release_name: ollama
    chart_source: unknown
    chart_ref: ollama-1.56.0
    chart_version: 1.56.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-ollama.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-ollama ollama-1.56.0 --namespace agent-testing --create-namespace --version 1.56.0 -f values/values-agent-ai-ollama.yaml --dry-run
      helm upgrade --install agent-ai-ollama ollama-1.56.0 --namespace agent-testing --create-namespace --version 1.56.0 -f values/values-agent-ai-ollama.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-ollama is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-12-agent-ai-ollama-llama70b
    title: Install Helm release agent-ai-ollama-llama70b
    type: helm_upgrade
    release_name: agent-ai-ollama-llama70b
    source_release_name: ollama-llama70b
    chart_source: unknown
    chart_ref: ollama-1.56.0
    chart_version: 1.56.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-ollama-llama70b.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama-llama70b]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing --create-namespace --version 1.56.0 -f values/values-agent-ai-ollama-llama70b.yaml --dry-run
      helm upgrade --install agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing --create-namespace --version 1.56.0 -f values/values-agent-ai-ollama-llama70b.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-ollama-llama70b is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-13-agent-ai-open-webui
    title: Install Helm release agent-ai-open-webui
    type: helm_upgrade
    release_name: agent-ai-open-webui
    source_release_name: open-webui
    chart_source: unknown
    chart_ref: open-webui-14.5.0
    chart_version: 14.5.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-open-webui.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:open-webui]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing --create-namespace --version 14.5.0 -f values/values-agent-ai-open-webui.yaml --dry-run
      helm upgrade --install agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing --create-namespace --version 14.5.0 -f values/values-agent-ai-open-webui.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-open-webui is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-14-agent-ai-postgresql
    title: Install Helm release agent-ai-postgresql
    type: helm_upgrade
    release_name: agent-ai-postgresql
    source_release_name: postgresql
    chart_source: unknown
    chart_ref: postgresql-18.5.6
    chart_version: 18.5.6
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-postgresql.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:postgresql]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing --create-namespace --version 18.5.6 -f values/values-agent-ai-postgresql.yaml --dry-run
      helm upgrade --install agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing --create-namespace --version 18.5.6 -f values/values-agent-ai-postgresql.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-postgresql is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-15-agent-ai-qdrant
    title: Install Helm release agent-ai-qdrant
    type: helm_upgrade
    release_name: agent-ai-qdrant
    source_release_name: qdrant
    chart_source: unknown
    chart_ref: qdrant-1.17.0
    chart_version: 1.17.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-qdrant.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:qdrant]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing --create-namespace --version 1.17.0 -f values/values-agent-ai-qdrant.yaml --dry-run
      helm upgrade --install agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing --create-namespace --version 1.17.0 -f values/values-agent-ai-qdrant.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-qdrant is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-16-agent-ai-redis
    title: Install Helm release agent-ai-redis
    type: helm_upgrade
    release_name: agent-ai-redis
    source_release_name: redis
    chart_source: unknown
    chart_ref: redis-25.3.9
    chart_version: 25.3.9
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-redis.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:redis]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-redis redis-25.3.9 --namespace agent-testing --create-namespace --version 25.3.9 -f values/values-agent-ai-redis.yaml --dry-run
      helm upgrade --install agent-ai-redis redis-25.3.9 --namespace agent-testing --create-namespace --version 25.3.9 -f values/values-agent-ai-redis.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-redis is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
  - step_id: helm-17-agent-ai-supabase
    title: Install Helm release agent-ai-supabase
    type: helm_upgrade
    release_name: agent-ai-supabase
    source_release_name: supabase
    chart_source: unknown
    chart_ref: supabase-0.5.4
    chart_version: 0.5.4
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-supabase.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:supabase]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-supabase supabase-0.5.4 --namespace agent-testing --create-namespace --version 0.5.4 -f values/values-agent-ai-supabase.yaml --dry-run
      helm upgrade --install agent-ai-supabase supabase-0.5.4 --namespace agent-testing --create-namespace --version 0.5.4 -f values/values-agent-ai-supabase.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-supabase is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Helm dry-runs render successfully before install commands are executed.
rollback:
  - helm uninstall agent-ai-supabase -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-redis -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-qdrant -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-postgresql -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-open-webui -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-ollama-llama70b -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-ollama -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-n8n -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-mongodb -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-langfuse -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-kafka-ui -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-kafka -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-clickhouse -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-release-note-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-mop-execution-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-mop-creation-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing --ignore-not-found
unknowns:
  []
evidence_refs:
TBD
```

### Phase 7 - Apply Raw Kubernetes Resources

```yaml
phase_id: apply_raw_kubernetes_resources
objective: Apply supported non-Helm resources in dependency order.
step_contract:
  dry_run_required: true
  namespace_explicit: true
  blocked_kinds_must_be_excluded: true
commands:
  - step_id: raw-1-deployment-bos-mcp-clickhouse
    title: Apply Deployment bos-mcp-clickhouse
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-clickhouse.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-clickhouse]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing
    expected: Deployment bos-mcp-clickhouse exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-2-deployment-bos-mcp-mongodb
    title: Apply Deployment bos-mcp-mongodb
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-mongodb.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-mongodb]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing
    expected: Deployment bos-mcp-mongodb exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-3-deployment-bos-mcp-qdrant
    title: Apply Deployment bos-mcp-qdrant
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-qdrant.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing
    expected: Deployment bos-mcp-qdrant exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-4-deployment-bos-mcp-qdrant-docs
    title: Apply Deployment bos-mcp-qdrant-docs
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-qdrant-docs.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant-docs]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing
    expected: Deployment bos-mcp-qdrant-docs exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-5-deployment-bosgenesis-helm-manager-mcp
    title: Apply Deployment bosgenesis-helm-manager-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing
    expected: Deployment bosgenesis-helm-manager-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-6-deployment-bosgenesis-k8s-inspector-mcp
    title: Apply Deployment bosgenesis-k8s-inspector-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
    expected: Deployment bosgenesis-k8s-inspector-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-7-deployment-bosgenesis-memory-agent-api
    title: Apply Deployment bosgenesis-memory-agent-api
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-memory-agent-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-memory-agent-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing
    expected: Deployment bosgenesis-memory-agent-api exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-8-deployment-ch-ui
    title: Apply Deployment ch-ui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-ch-ui.yaml -n agent-testing
    expected: Deployment ch-ui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-9-deployment-dify-api
    title: Apply Deployment dify-api
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-dify-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-dify-api.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-dify-api.yaml -n agent-testing
    expected: Deployment dify-api exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-10-deployment-dify-plugin-daemon
    title: Apply Deployment dify-plugin-daemon
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-dify-plugin-daemon.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-plugin-daemon]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing
    expected: Deployment dify-plugin-daemon exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-11-deployment-dify-web
    title: Apply Deployment dify-web
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-dify-web.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-web]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-dify-web.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-dify-web.yaml -n agent-testing
    expected: Deployment dify-web exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-12-deployment-dify-worker
    title: Apply Deployment dify-worker
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-dify-worker.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-worker]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-dify-worker.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-dify-worker.yaml -n agent-testing
    expected: Deployment dify-worker exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-13-deployment-langflow
    title: Apply Deployment langflow
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-langflow.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:langflow]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-langflow.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-langflow.yaml -n agent-testing
    expected: Deployment langflow exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-14-deployment-letta
    title: Apply Deployment letta
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-letta.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-letta.yaml -n agent-testing
    expected: Deployment letta exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-15-deployment-redisinsight
    title: Apply Deployment redisinsight
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/deployment-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/deployment-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/deployment-redisinsight.yaml -n agent-testing
    expected: Deployment redisinsight exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-16-service-bos-mcp-clickhouse-svc
    title: Apply Service bos-mcp-clickhouse-svc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-clickhouse-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-clickhouse-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing
    expected: Service bos-mcp-clickhouse-svc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-17-service-bos-mcp-mongodb-svc
    title: Apply Service bos-mcp-mongodb-svc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-mongodb-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-mongodb-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing
    expected: Service bos-mcp-mongodb-svc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-18-service-bos-mcp-qdrant-docs-svc
    title: Apply Service bos-mcp-qdrant-docs-svc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-qdrant-docs-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-docs-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing
    expected: Service bos-mcp-qdrant-docs-svc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-19-service-bos-mcp-qdrant-svc
    title: Apply Service bos-mcp-qdrant-svc
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-qdrant-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing
    expected: Service bos-mcp-qdrant-svc exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-20-service-bosgenesis-helm-manager-mcp
    title: Apply Service bosgenesis-helm-manager-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing
    expected: Service bosgenesis-helm-manager-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-21-service-bosgenesis-k8s-inspector-mcp
    title: Apply Service bosgenesis-k8s-inspector-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
    expected: Service bosgenesis-k8s-inspector-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-22-service-bosgenesis-memory-agent-api
    title: Apply Service bosgenesis-memory-agent-api
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-memory-agent-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-memory-agent-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing
    expected: Service bosgenesis-memory-agent-api exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-23-service-ch-ui
    title: Apply Service ch-ui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-ch-ui.yaml -n agent-testing
    expected: Service ch-ui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-24-service-dify-api
    title: Apply Service dify-api
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-dify-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-dify-api.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-dify-api.yaml -n agent-testing
    expected: Service dify-api exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-25-service-dify-plugin-daemon
    title: Apply Service dify-plugin-daemon
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-dify-plugin-daemon.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-plugin-daemon]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-dify-plugin-daemon.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-dify-plugin-daemon.yaml -n agent-testing
    expected: Service dify-plugin-daemon exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-26-service-dify-web
    title: Apply Service dify-web
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-dify-web.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-web]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-dify-web.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-dify-web.yaml -n agent-testing
    expected: Service dify-web exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-27-service-langflow
    title: Apply Service langflow
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-langflow.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:langflow]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-langflow.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-langflow.yaml -n agent-testing
    expected: Service langflow exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-28-service-letta
    title: Apply Service letta
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-letta.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-letta.yaml -n agent-testing
    expected: Service letta exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-29-service-mongodb-nodeport
    title: Apply Service mongodb-nodeport
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-mongodb-nodeport.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:mongodb-nodeport]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-mongodb-nodeport.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-mongodb-nodeport.yaml -n agent-testing
    expected: Service mongodb-nodeport exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-30-service-redisinsight
    title: Apply Service redisinsight
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/service-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/service-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/service-redisinsight.yaml -n agent-testing
    expected: Service redisinsight exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Raw Kubernetes manifests are accepted by server-side dry-run before apply.
rollback:
  - kubectl delete -f generated/service-redisinsight.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-mongodb-nodeport.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-letta.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-langflow.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-web.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-ch-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-redisinsight.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-letta.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-langflow.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-worker.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-web.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-ch-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 8 - Apply Ingress

```yaml
phase_id: apply_ingress
objective: Apply ingress resources after backend services are available.
commands:
  - step_id: raw-1-ingress-agent-ai-bosgenesis-helm-manager-mcp
    title: Apply Ingress agent-ai-bosgenesis-helm-manager-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-helm-manager-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-2-ingress-agent-ai-bosgenesis-k8s-inspector-mcp
    title: Apply Ingress agent-ai-bosgenesis-k8s-inspector-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-k8s-inspector-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-3-ingress-agent-ai-ch-ui
    title: Apply Ingress agent-ai-ch-ui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing
    expected: Ingress agent-ai-ch-ui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-4-ingress-agent-ai-clickhouse-mcp
    title: Apply Ingress agent-ai-clickhouse-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-clickhouse-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:clickhouse-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-clickhouse-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-5-ingress-agent-ai-dify
    title: Apply Ingress agent-ai-dify
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-dify.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:dify]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-dify.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-dify.yaml -n agent-testing
    expected: Ingress agent-ai-dify exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-6-ingress-agent-ai-langflow-ingress
    title: Apply Ingress agent-ai-langflow-ingress
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-langflow-ingress.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langflow-ingress]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing
    expected: Ingress agent-ai-langflow-ingress exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-7-ingress-agent-ai-langfuse
    title: Apply Ingress agent-ai-langfuse
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-langfuse.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langfuse]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing
    expected: Ingress agent-ai-langfuse exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-8-ingress-agent-ai-letta
    title: Apply Ingress agent-ai-letta
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-letta.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-letta.yaml -n agent-testing
    expected: Ingress agent-ai-letta exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-9-ingress-agent-ai-memory-agent-ingress
    title: Apply Ingress agent-ai-memory-agent-ingress
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-memory-agent-ingress.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:memory-agent-ingress]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing
    expected: Ingress agent-ai-memory-agent-ingress exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-10-ingress-agent-ai-mongodb-mcp
    title: Apply Ingress agent-ai-mongodb-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-mongodb-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:mongodb-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-mongodb-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-11-ingress-agent-ai-ollama
    title: Apply Ingress agent-ai-ollama
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ollama.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-ollama.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-ollama.yaml -n agent-testing
    expected: Ingress agent-ai-ollama exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-12-ingress-agent-ai-ollama-llama70b
    title: Apply Ingress agent-ai-ollama-llama70b
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ollama-llama70b.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama-llama70b]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing
    expected: Ingress agent-ai-ollama-llama70b exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-13-ingress-agent-ai-open-webui
    title: Apply Ingress agent-ai-open-webui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-open-webui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:open-webui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing
    expected: Ingress agent-ai-open-webui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-14-ingress-agent-ai-qdrant
    title: Apply Ingress agent-ai-qdrant
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing
    expected: Ingress agent-ai-qdrant exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-15-ingress-agent-ai-qdrant-docs-mcp
    title: Apply Ingress agent-ai-qdrant-docs-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant-docs-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-docs-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-qdrant-docs-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-16-ingress-agent-ai-qdrant-mcp
    title: Apply Ingress agent-ai-qdrant-mcp
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing
    expected: Ingress agent-ai-qdrant-mcp exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-17-ingress-agent-ai-redisinsight
    title: Apply Ingress agent-ai-redisinsight
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing
    expected: Ingress agent-ai-redisinsight exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-18-ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent
    title: Apply Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-data-ingestion-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-19-ingress-agent-ai-bosgenesis-mop-creation-agent
    title: Apply Ingress agent-ai-bosgenesis-mop-creation-agent
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-creation-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-mop-creation-agent exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-20-ingress-agent-ai-bosgenesis-mop-execution-agent
    title: Apply Ingress agent-ai-bosgenesis-mop-execution-agent
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-execution-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-mop-execution-agent exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-21-ingress-agent-ai-bosgenesis-release-note-agent
    title: Apply Ingress agent-ai-bosgenesis-release-note-agent
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-release-note-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing
    expected: Ingress agent-ai-bosgenesis-release-note-agent exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-22-ingress-agent-ai-kafka-ui
    title: Apply Ingress agent-ai-kafka-ui
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-kafka-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:kafka-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing
    expected: Ingress agent-ai-kafka-ui exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-23-ingress-agent-ai-n8n-main
    title: Apply Ingress agent-ai-n8n-main
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-n8n-main.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:n8n-main]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing
    expected: Ingress agent-ai-n8n-main exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-24-ingress-agent-ai-supabase-supabase-kong
    title: Apply Ingress agent-ai-supabase-supabase-kong
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-supabase-supabase-kong.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:supabase-supabase-kong]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing
    expected: Ingress agent-ai-supabase-supabase-kong exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Ingress resources are accepted by dry-run and then applied when approved.
rollback:
  - kubectl delete -f generated/ingress-agent-ai-supabase-supabase-kong.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-n8n-main.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-kafka-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-redisinsight.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-qdrant-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-qdrant-docs-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-qdrant.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-open-webui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-ollama-llama70b.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-ollama.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-mongodb-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-memory-agent-ingress.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-letta.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-langfuse.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-langflow-ingress.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-dify.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-clickhouse-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-ch-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 9 - Application Metadata Recreation

```yaml
phase_id: apply_application_metadata
enabled_when: generation_mode == "application"
objective: Recreate metadata-only schemas, topics, and topology without data.
targets:
  []
commands_or_guidance:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - No schemas, topics, or topology are created.
rollback:
  - No rollback required.
evidence_refs:
  - artifact.json
```

### Phase 10 - Validate

```yaml
phase_id: validate
objective: Confirm recreated namespace resources are healthy.
commands:
  - step_id: validate-preflight-1
    title: Validation command 1
    type: k8s_validate
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get all,configmap,pvc,ingress -n agent-testing
    expected: Command succeeds and expected resources are visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-preflight-2
    title: Validation command 2
    type: context_check
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      helm list -n agent-testing
    expected: Command succeeds and expected resources are visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-1-agent-ai-bosgenesis-k8s-data-ingestion-agent
    title: Validate Helm release agent-ai-bosgenesis-k8s-data-ingestion-agent
    type: helm_validate
    release_name: agent-ai-bosgenesis-k8s-data-ingestion-agent
    chart_source: unknown
    chart_ref: bosgenesis-k8s-data-ingestion-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-k8s-data-ingestion-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-bosgenesis-k8s-data-ingestion-agent bosgenesis-k8s-data-ingestion-agent-0.1.0 --namespace agent-testing -f values/values-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml --version 0.1.0
      helm status agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-2-agent-ai-bosgenesis-mop-creation-agent
    title: Validate Helm release agent-ai-bosgenesis-mop-creation-agent
    type: helm_validate
    release_name: agent-ai-bosgenesis-mop-creation-agent
    chart_source: unknown
    chart_ref: bosgenesis-mop-creation-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-mop-creation-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-creation-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-bosgenesis-mop-creation-agent bosgenesis-mop-creation-agent-0.1.0 --namespace agent-testing -f values/values-agent-ai-bosgenesis-mop-creation-agent.yaml --version 0.1.0
      helm status agent-ai-bosgenesis-mop-creation-agent -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-3-agent-ai-bosgenesis-mop-execution-agent
    title: Validate Helm release agent-ai-bosgenesis-mop-execution-agent
    type: helm_validate
    release_name: agent-ai-bosgenesis-mop-execution-agent
    chart_source: unknown
    chart_ref: bosgenesis-mop-execution-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-mop-execution-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-mop-execution-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-bosgenesis-mop-execution-agent bosgenesis-mop-execution-agent-0.1.0 --namespace agent-testing -f values/values-agent-ai-bosgenesis-mop-execution-agent.yaml --version 0.1.0
      helm status agent-ai-bosgenesis-mop-execution-agent -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-4-agent-ai-bosgenesis-release-note-agent
    title: Validate Helm release agent-ai-bosgenesis-release-note-agent
    type: helm_validate
    release_name: agent-ai-bosgenesis-release-note-agent
    chart_source: unknown
    chart_ref: bosgenesis-release-note-agent-0.1.0
    chart_version: 0.1.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-bosgenesis-release-note-agent.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:bosgenesis-release-note-agent]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-bosgenesis-release-note-agent bosgenesis-release-note-agent-0.1.0 --namespace agent-testing -f values/values-agent-ai-bosgenesis-release-note-agent.yaml --version 0.1.0
      helm status agent-ai-bosgenesis-release-note-agent -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-5-agent-ai-clickhouse
    title: Validate Helm release agent-ai-clickhouse
    type: helm_validate
    release_name: agent-ai-clickhouse
    chart_source: unknown
    chart_ref: clickhouse-9.4.4
    chart_version: 9.4.4
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-clickhouse.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:clickhouse]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-clickhouse clickhouse-9.4.4 --namespace agent-testing -f values/values-agent-ai-clickhouse.yaml --version 9.4.4
      helm status agent-ai-clickhouse -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-6-agent-ai-kafka
    title: Validate Helm release agent-ai-kafka
    type: helm_validate
    release_name: agent-ai-kafka
    chart_source: unknown
    chart_ref: kafka-32.4.3
    chart_version: 32.4.3
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-kafka.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-kafka kafka-32.4.3 --namespace agent-testing -f values/values-agent-ai-kafka.yaml --version 32.4.3
      helm status agent-ai-kafka -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-7-agent-ai-kafka-ui
    title: Validate Helm release agent-ai-kafka-ui
    type: helm_validate
    release_name: agent-ai-kafka-ui
    chart_source: unknown
    chart_ref: kafka-ui-0.7.6
    chart_version: 0.7.6
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-kafka-ui.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:kafka-ui]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-kafka-ui kafka-ui-0.7.6 --namespace agent-testing -f values/values-agent-ai-kafka-ui.yaml --version 0.7.6
      helm status agent-ai-kafka-ui -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-8-agent-ai-langfuse
    title: Validate Helm release agent-ai-langfuse
    type: helm_validate
    release_name: agent-ai-langfuse
    chart_source: unknown
    chart_ref: langfuse-1.5.29
    chart_version: 1.5.29
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-langfuse.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:langfuse]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-langfuse langfuse-1.5.29 --namespace agent-testing -f values/values-agent-ai-langfuse.yaml --version 1.5.29
      helm status agent-ai-langfuse -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-9-agent-ai-mongodb
    title: Validate Helm release agent-ai-mongodb
    type: helm_validate
    release_name: agent-ai-mongodb
    chart_source: unknown
    chart_ref: mongodb-18.6.21
    chart_version: 18.6.21
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-mongodb.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:mongodb]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-mongodb mongodb-18.6.21 --namespace agent-testing -f values/values-agent-ai-mongodb.yaml --version 18.6.21
      helm status agent-ai-mongodb -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-10-agent-ai-n8n
    title: Validate Helm release agent-ai-n8n
    type: helm_validate
    release_name: agent-ai-n8n
    chart_source: unknown
    chart_ref: n8n-1.0.0
    chart_version: 1.0.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-n8n.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:n8n]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-n8n n8n-1.0.0 --namespace agent-testing -f values/values-agent-ai-n8n.yaml --version 1.0.0
      helm status agent-ai-n8n -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-11-agent-ai-ollama
    title: Validate Helm release agent-ai-ollama
    type: helm_validate
    release_name: agent-ai-ollama
    chart_source: unknown
    chart_ref: ollama-1.56.0
    chart_version: 1.56.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-ollama.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-ollama ollama-1.56.0 --namespace agent-testing -f values/values-agent-ai-ollama.yaml --version 1.56.0
      helm status agent-ai-ollama -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-12-agent-ai-ollama-llama70b
    title: Validate Helm release agent-ai-ollama-llama70b
    type: helm_validate
    release_name: agent-ai-ollama-llama70b
    chart_source: unknown
    chart_ref: ollama-1.56.0
    chart_version: 1.56.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-ollama-llama70b.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:ollama-llama70b]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-ollama-llama70b ollama-1.56.0 --namespace agent-testing -f values/values-agent-ai-ollama-llama70b.yaml --version 1.56.0
      helm status agent-ai-ollama-llama70b -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-13-agent-ai-open-webui
    title: Validate Helm release agent-ai-open-webui
    type: helm_validate
    release_name: agent-ai-open-webui
    chart_source: unknown
    chart_ref: open-webui-14.5.0
    chart_version: 14.5.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-open-webui.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:open-webui]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-open-webui open-webui-14.5.0 --namespace agent-testing -f values/values-agent-ai-open-webui.yaml --version 14.5.0
      helm status agent-ai-open-webui -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-14-agent-ai-postgresql
    title: Validate Helm release agent-ai-postgresql
    type: helm_validate
    release_name: agent-ai-postgresql
    chart_source: unknown
    chart_ref: postgresql-18.5.6
    chart_version: 18.5.6
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-postgresql.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:postgresql]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-postgresql postgresql-18.5.6 --namespace agent-testing -f values/values-agent-ai-postgresql.yaml --version 18.5.6
      helm status agent-ai-postgresql -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-15-agent-ai-qdrant
    title: Validate Helm release agent-ai-qdrant
    type: helm_validate
    release_name: agent-ai-qdrant
    chart_source: unknown
    chart_ref: qdrant-1.17.0
    chart_version: 1.17.0
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-qdrant.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:qdrant]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-qdrant qdrant-1.17.0 --namespace agent-testing -f values/values-agent-ai-qdrant.yaml --version 1.17.0
      helm status agent-ai-qdrant -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-16-agent-ai-redis
    title: Validate Helm release agent-ai-redis
    type: helm_validate
    release_name: agent-ai-redis
    chart_source: unknown
    chart_ref: redis-25.3.9
    chart_version: 25.3.9
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-redis.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:redis]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-redis redis-25.3.9 --namespace agent-testing -f values/values-agent-ai-redis.yaml --version 25.3.9
      helm status agent-ai-redis -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-17-agent-ai-supabase
    title: Validate Helm release agent-ai-supabase
    type: helm_validate
    release_name: agent-ai-supabase
    chart_source: unknown
    chart_ref: supabase-0.5.4
    chart_version: 0.5.4
    repo_name: 
    repo_url: 
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-supabase.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:helm_mcp:bosgenesis:HelmRelease:supabase]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as operator evidence; values are redacted before use.
    command: |
      helm template agent-ai-supabase supabase-0.5.4 --namespace agent-testing -f values/values-agent-ai-supabase.yaml --version 0.5.4
      helm status agent-ai-supabase -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-1-ConfigMap-bosgenesis-helm-manager-mcp-config
    title: Validate ConfigMap bosgenesis-helm-manager-mcp-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-bosgenesis-helm-manager-mcp-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-helm-manager-mcp-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap bosgenesis-helm-manager-mcp-config -n agent-testing -o wide
    expected: ConfigMap bosgenesis-helm-manager-mcp-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-2-ConfigMap-bosgenesis-k8s-inspector-mcp-config
    title: Validate ConfigMap bosgenesis-k8s-inspector-mcp-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-bosgenesis-k8s-inspector-mcp-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:bosgenesis-k8s-inspector-mcp-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap bosgenesis-k8s-inspector-mcp-config -n agent-testing -o wide
    expected: ConfigMap bosgenesis-k8s-inspector-mcp-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-3-ConfigMap-dify-config
    title: Validate ConfigMap dify-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-dify-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:dify-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap dify-config -n agent-testing -o wide
    expected: ConfigMap dify-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-4-ConfigMap-istio-ca-crl
    title: Validate ConfigMap istio-ca-crl
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-crl.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-crl]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap istio-ca-crl -n agent-testing -o wide
    expected: ConfigMap istio-ca-crl exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-5-ConfigMap-istio-ca-root-cert
    title: Validate ConfigMap istio-ca-root-cert
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-root-cert.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:istio-ca-root-cert]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
    expected: ConfigMap istio-ca-root-cert exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-6-ConfigMap-kube-root-ca.crt
    title: Validate ConfigMap kube-root-ca.crt
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-kube-root-ca.crt.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:kube-root-ca.crt]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
    expected: ConfigMap kube-root-ca.crt exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-7-ConfigMap-langflow-config
    title: Validate ConfigMap langflow-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-langflow-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:langflow-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap langflow-config -n agent-testing -o wide
    expected: ConfigMap langflow-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-8-ConfigMap-letta-config
    title: Validate ConfigMap letta-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-letta-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:letta-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap letta-config -n agent-testing -o wide
    expected: ConfigMap letta-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-9-ConfigMap-memory-agent-config
    title: Validate ConfigMap memory-agent-config
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-memory-agent-config.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:ConfigMap:bosgenesis:memory-agent-config]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap memory-agent-config -n agent-testing -o wide
    expected: ConfigMap memory-agent-config exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-10-Deployment-bos-mcp-clickhouse
    title: Validate Deployment bos-mcp-clickhouse
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-clickhouse.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-clickhouse]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bos-mcp-clickhouse -n agent-testing -o wide
    expected: Deployment bos-mcp-clickhouse exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-11-Deployment-bos-mcp-mongodb
    title: Validate Deployment bos-mcp-mongodb
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-mongodb.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-mongodb]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bos-mcp-mongodb -n agent-testing -o wide
    expected: Deployment bos-mcp-mongodb exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-12-Deployment-bos-mcp-qdrant
    title: Validate Deployment bos-mcp-qdrant
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-qdrant.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bos-mcp-qdrant -n agent-testing -o wide
    expected: Deployment bos-mcp-qdrant exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-13-Deployment-bos-mcp-qdrant-docs
    title: Validate Deployment bos-mcp-qdrant-docs
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bos-mcp-qdrant-docs.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bos-mcp-qdrant-docs]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bos-mcp-qdrant-docs -n agent-testing -o wide
    expected: Deployment bos-mcp-qdrant-docs exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-14-Deployment-bosgenesis-helm-manager-mcp
    title: Validate Deployment bosgenesis-helm-manager-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bosgenesis-helm-manager-mcp -n agent-testing -o wide
    expected: Deployment bosgenesis-helm-manager-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-15-Deployment-bosgenesis-k8s-inspector-mcp
    title: Validate Deployment bosgenesis-k8s-inspector-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
    expected: Deployment bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-16-Deployment-bosgenesis-memory-agent-api
    title: Validate Deployment bosgenesis-memory-agent-api
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-bosgenesis-memory-agent-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:bosgenesis-memory-agent-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment bosgenesis-memory-agent-api -n agent-testing -o wide
    expected: Deployment bosgenesis-memory-agent-api exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-17-Deployment-ch-ui
    title: Validate Deployment ch-ui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment ch-ui -n agent-testing -o wide
    expected: Deployment ch-ui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-18-Deployment-dify-api
    title: Validate Deployment dify-api
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-dify-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment dify-api -n agent-testing -o wide
    expected: Deployment dify-api exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-19-Deployment-dify-plugin-daemon
    title: Validate Deployment dify-plugin-daemon
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-dify-plugin-daemon.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-plugin-daemon]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment dify-plugin-daemon -n agent-testing -o wide
    expected: Deployment dify-plugin-daemon exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-20-Deployment-dify-web
    title: Validate Deployment dify-web
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-dify-web.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-web]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment dify-web -n agent-testing -o wide
    expected: Deployment dify-web exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-21-Deployment-dify-worker
    title: Validate Deployment dify-worker
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-dify-worker.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:dify-worker]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment dify-worker -n agent-testing -o wide
    expected: Deployment dify-worker exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-22-Deployment-langflow
    title: Validate Deployment langflow
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-langflow.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:langflow]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment langflow -n agent-testing -o wide
    expected: Deployment langflow exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-23-Deployment-letta
    title: Validate Deployment letta
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment letta -n agent-testing -o wide
    expected: Deployment letta exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-24-Deployment-redisinsight
    title: Validate Deployment redisinsight
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/deployment-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Deployment:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get deployment redisinsight -n agent-testing -o wide
    expected: Deployment redisinsight exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-25-Ingress-agent-ai-bosgenesis-helm-manager-mcp
    title: Validate Ingress agent-ai-bosgenesis-helm-manager-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-helm-manager-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-helm-manager-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-26-Ingress-agent-ai-bosgenesis-k8s-inspector-mcp
    title: Validate Ingress agent-ai-bosgenesis-k8s-inspector-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-27-Ingress-agent-ai-ch-ui
    title: Validate Ingress agent-ai-ch-ui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-ch-ui -n agent-testing -o wide
    expected: Ingress agent-ai-ch-ui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-28-Ingress-agent-ai-clickhouse-mcp
    title: Validate Ingress agent-ai-clickhouse-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-clickhouse-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:clickhouse-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-clickhouse-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-clickhouse-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-29-Ingress-agent-ai-dify
    title: Validate Ingress agent-ai-dify
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-dify.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:dify]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-dify -n agent-testing -o wide
    expected: Ingress agent-ai-dify exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-30-Ingress-agent-ai-langflow-ingress
    title: Validate Ingress agent-ai-langflow-ingress
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-langflow-ingress.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langflow-ingress]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-langflow-ingress -n agent-testing -o wide
    expected: Ingress agent-ai-langflow-ingress exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-31-Ingress-agent-ai-langfuse
    title: Validate Ingress agent-ai-langfuse
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-langfuse.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:langfuse]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-langfuse -n agent-testing -o wide
    expected: Ingress agent-ai-langfuse exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-32-Ingress-agent-ai-letta
    title: Validate Ingress agent-ai-letta
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-letta -n agent-testing -o wide
    expected: Ingress agent-ai-letta exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-33-Ingress-agent-ai-memory-agent-ingress
    title: Validate Ingress agent-ai-memory-agent-ingress
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-memory-agent-ingress.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:memory-agent-ingress]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-memory-agent-ingress -n agent-testing -o wide
    expected: Ingress agent-ai-memory-agent-ingress exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-34-Ingress-agent-ai-mongodb-mcp
    title: Validate Ingress agent-ai-mongodb-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-mongodb-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:mongodb-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-mongodb-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-mongodb-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-35-Ingress-agent-ai-ollama
    title: Validate Ingress agent-ai-ollama
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ollama.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-ollama -n agent-testing -o wide
    expected: Ingress agent-ai-ollama exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-36-Ingress-agent-ai-ollama-llama70b
    title: Validate Ingress agent-ai-ollama-llama70b
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-ollama-llama70b.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:ollama-llama70b]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-ollama-llama70b -n agent-testing -o wide
    expected: Ingress agent-ai-ollama-llama70b exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-37-Ingress-agent-ai-open-webui
    title: Validate Ingress agent-ai-open-webui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-open-webui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:open-webui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-open-webui -n agent-testing -o wide
    expected: Ingress agent-ai-open-webui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-38-Ingress-agent-ai-qdrant
    title: Validate Ingress agent-ai-qdrant
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-qdrant -n agent-testing -o wide
    expected: Ingress agent-ai-qdrant exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-39-Ingress-agent-ai-qdrant-docs-mcp
    title: Validate Ingress agent-ai-qdrant-docs-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant-docs-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-docs-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-qdrant-docs-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-qdrant-docs-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-40-Ingress-agent-ai-qdrant-mcp
    title: Validate Ingress agent-ai-qdrant-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-qdrant-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:qdrant-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-qdrant-mcp -n agent-testing -o wide
    expected: Ingress agent-ai-qdrant-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-41-Ingress-agent-ai-redisinsight
    title: Validate Ingress agent-ai-redisinsight
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-redisinsight -n agent-testing -o wide
    expected: Ingress agent-ai-redisinsight exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-42-PersistentVolumeClaim-ch-ui
    title: Validate PersistentVolumeClaim ch-ui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim ch-ui -n agent-testing -o wide
    expected: PersistentVolumeClaim ch-ui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-43-PersistentVolumeClaim-dify-storage
    title: Validate PersistentVolumeClaim dify-storage
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-dify-storage.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:dify-storage]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim dify-storage -n agent-testing -o wide
    expected: PersistentVolumeClaim dify-storage exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-44-PersistentVolumeClaim-langflow-pvc
    title: Validate PersistentVolumeClaim langflow-pvc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-langflow-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:langflow-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim langflow-pvc -n agent-testing -o wide
    expected: PersistentVolumeClaim langflow-pvc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-45-PersistentVolumeClaim-memory-agent-lancedb-pvc
    title: Validate PersistentVolumeClaim memory-agent-lancedb-pvc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-memory-agent-lancedb-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:memory-agent-lancedb-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim memory-agent-lancedb-pvc -n agent-testing -o wide
    expected: PersistentVolumeClaim memory-agent-lancedb-pvc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-46-PersistentVolumeClaim-ollama
    title: Validate PersistentVolumeClaim ollama
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-ollama.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:ollama]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim ollama -n agent-testing -o wide
    expected: PersistentVolumeClaim ollama exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-47-PersistentVolumeClaim-redisinsight-pvc
    title: Validate PersistentVolumeClaim redisinsight-pvc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/persistentvolumeclaim-redisinsight-pvc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:PersistentVolumeClaim:bosgenesis:redisinsight-pvc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get persistentvolumeclaim redisinsight-pvc -n agent-testing -o wide
    expected: PersistentVolumeClaim redisinsight-pvc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-48-Service-bos-mcp-clickhouse-svc
    title: Validate Service bos-mcp-clickhouse-svc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-clickhouse-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-clickhouse-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bos-mcp-clickhouse-svc -n agent-testing -o wide
    expected: Service bos-mcp-clickhouse-svc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-49-Service-bos-mcp-mongodb-svc
    title: Validate Service bos-mcp-mongodb-svc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-mongodb-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-mongodb-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bos-mcp-mongodb-svc -n agent-testing -o wide
    expected: Service bos-mcp-mongodb-svc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-50-Service-bos-mcp-qdrant-docs-svc
    title: Validate Service bos-mcp-qdrant-docs-svc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-qdrant-docs-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-docs-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bos-mcp-qdrant-docs-svc -n agent-testing -o wide
    expected: Service bos-mcp-qdrant-docs-svc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-51-Service-bos-mcp-qdrant-svc
    title: Validate Service bos-mcp-qdrant-svc
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bos-mcp-qdrant-svc.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bos-mcp-qdrant-svc]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bos-mcp-qdrant-svc -n agent-testing -o wide
    expected: Service bos-mcp-qdrant-svc exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-52-Service-bosgenesis-helm-manager-mcp
    title: Validate Service bosgenesis-helm-manager-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-helm-manager-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-helm-manager-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bosgenesis-helm-manager-mcp -n agent-testing -o wide
    expected: Service bosgenesis-helm-manager-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-53-Service-bosgenesis-k8s-inspector-mcp
    title: Validate Service bosgenesis-k8s-inspector-mcp
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-k8s-inspector-mcp.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-k8s-inspector-mcp]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bosgenesis-k8s-inspector-mcp -n agent-testing -o wide
    expected: Service bosgenesis-k8s-inspector-mcp exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-54-Service-bosgenesis-memory-agent-api
    title: Validate Service bosgenesis-memory-agent-api
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-bosgenesis-memory-agent-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:bosgenesis-memory-agent-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service bosgenesis-memory-agent-api -n agent-testing -o wide
    expected: Service bosgenesis-memory-agent-api exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-55-Service-ch-ui
    title: Validate Service ch-ui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-ch-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:ch-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service ch-ui -n agent-testing -o wide
    expected: Service ch-ui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-56-Service-dify-api
    title: Validate Service dify-api
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-dify-api.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-api]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service dify-api -n agent-testing -o wide
    expected: Service dify-api exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-57-Service-dify-plugin-daemon
    title: Validate Service dify-plugin-daemon
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-dify-plugin-daemon.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-plugin-daemon]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service dify-plugin-daemon -n agent-testing -o wide
    expected: Service dify-plugin-daemon exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-58-Service-dify-web
    title: Validate Service dify-web
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-dify-web.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:dify-web]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service dify-web -n agent-testing -o wide
    expected: Service dify-web exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-59-Service-langflow
    title: Validate Service langflow
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-langflow.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:langflow]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service langflow -n agent-testing -o wide
    expected: Service langflow exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-60-Service-letta
    title: Validate Service letta
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-letta.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:letta]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service letta -n agent-testing -o wide
    expected: Service letta exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-61-Service-mongodb-nodeport
    title: Validate Service mongodb-nodeport
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-mongodb-nodeport.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:mongodb-nodeport]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service mongodb-nodeport -n agent-testing -o wide
    expected: Service mongodb-nodeport exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-62-Service-redisinsight
    title: Validate Service redisinsight
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/service-redisinsight.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Service:bosgenesis:redisinsight]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get service redisinsight -n agent-testing -o wide
    expected: Service redisinsight exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-63-Ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent
    title: Validate Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-k8s-data-ingestion-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-k8s-data-ingestion-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-k8s-data-ingestion-agent exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-64-Ingress-agent-ai-bosgenesis-mop-creation-agent
    title: Validate Ingress agent-ai-bosgenesis-mop-creation-agent
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-mop-creation-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-creation-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-mop-creation-agent -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-mop-creation-agent exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-65-Ingress-agent-ai-bosgenesis-mop-execution-agent
    title: Validate Ingress agent-ai-bosgenesis-mop-execution-agent
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-mop-execution-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-mop-execution-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-mop-execution-agent -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-mop-execution-agent exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-66-Ingress-agent-ai-bosgenesis-release-note-agent
    title: Validate Ingress agent-ai-bosgenesis-release-note-agent
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-bosgenesis-release-note-agent.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:bosgenesis-release-note-agent]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-bosgenesis-release-note-agent -n agent-testing -o wide
    expected: Ingress agent-ai-bosgenesis-release-note-agent exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-67-Ingress-agent-ai-kafka-ui
    title: Validate Ingress agent-ai-kafka-ui
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-kafka-ui.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:kafka-ui]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-kafka-ui -n agent-testing -o wide
    expected: Ingress agent-ai-kafka-ui exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-68-Ingress-agent-ai-n8n-main
    title: Validate Ingress agent-ai-n8n-main
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-n8n-main.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:n8n-main]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-n8n-main -n agent-testing -o wide
    expected: Ingress agent-ai-n8n-main exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-69-Ingress-agent-ai-supabase-supabase-kong
    title: Validate Ingress agent-ai-supabase-supabase-kong
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-supabase-supabase-kong.yaml]
    evidence_refs: [postgres+mcp_live:af085c21-888c-49f8-ada0-5da4535067e0:Ingress:bosgenesis:supabase-supabase-kong]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-supabase-supabase-kong -n agent-testing -o wide
    expected: Ingress agent-ai-supabase-supabase-kong exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - Generated files exist and target namespace dry-run commands succeed.
stop_conditions:
  - Required MoP sections are missing.
evidence_refs:
  - artifact.json
```

## 9. Go / No-Go Matrix

```yaml
go_no_go:
  - checkpoint: Required artifact files exist
    expected: true
    action_if_failed: STOP
```

## 10. Rollback Plan

```yaml
rollback:
  trigger_conditions:
  - Any approved install/apply command fails after mutation begins.
  helm:
  - helm uninstall agent-ai-supabase -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-redis -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-qdrant -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-postgresql -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-open-webui -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-ollama-llama70b -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-ollama -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-n8n -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-mongodb -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-langfuse -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-kafka-ui -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-kafka -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-clickhouse -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-release-note-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-mop-execution-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-mop-creation-agent -n agent-testing --ignore-not-found
  - helm uninstall agent-ai-bosgenesis-k8s-data-ingestion-agent -n agent-testing --ignore-not-found
  raw_kubernetes:
  - kubectl delete -f generated/service-redisinsight.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-mongodb-nodeport.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-letta.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-langflow.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-web.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-dify-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-ch-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-qdrant-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-qdrant-docs-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-mongodb-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/service-bos-mcp-clickhouse-svc.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-redisinsight.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-letta.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-langflow.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-worker.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-web.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-plugin-daemon.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-dify-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-ch-ui.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-memory-agent-api.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-k8s-inspector-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bosgenesis-helm-manager-mcp.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-qdrant-docs.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-qdrant.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-mongodb.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/deployment-bos-mcp-clickhouse.yaml -n agent-testing --ignore-not-found
  application_metadata:
  - No rollback required.
  namespace_cleanup:
  - Delete target namespace only with explicit approval.
```

## 11. Inference and Confidence

```yaml
inferences:
  - label: observed_or_inferred
    confidence: medium
    rationale: Deterministic reconstruction writes normalized manifests and Helm values from available evidence; missing chart refs or specs require human completion.
    authority_order: Observed evidence > deterministic reconstruction > Qdrant prior references > LLM suggestion > human approval
  - label: bounded_llm_reasoning_no_high_confidence_findings
    confidence: high
    rationale: No executable YAML or Helm command was generated by the bounded reasoning layer.
    executable_yaml_allowed: false
  - label: llm_repair_no_high_confidence_suggestions
    confidence: high
    rationale: No executable YAML was generated by the LLM repair layer.
    executable_yaml_allowed: false
unknowns:
  - Exact install command synthesis requires a later generation phase.
  - Secret values are intentionally unavailable and must be supplied by humans.
confidence_summary:
  overall: medium_when_snapshot_found_low_when_missing
  bounded_llm_reasoning_status: no_high_confidence_findings
  bounded_llm_reasoning_accepted_findings: 0
  llm_repair_status: no_high_confidence_suggestions
  llm_repair_accepted_suggestions: 0
  llm_output_authoritative: false
```

## 12. Excluded Resources

```yaml
excluded_resources:
  []
exclusion_policy:
  - Secret values are never copied.
  - Cluster-scoped resources are out of v1 scope.
  - Unsupported namespaced resources require manual review.
```

## 13. Artifact References

```yaml
artifacts:
  human_mop_pdf: "/data/mops/d1d1ab47-1778-4ec6-b186-30f6a85e1756/mop-bosgenesis-to-agent-testing-20260705T021053Z.pdf"
  installation_notes: "/data/mops/d1d1ab47-1778-4ec6-b186-30f6a85e1756/mop-bosgenesis-to-agent-testing-20260705T021053Z.installation.md"
  generated_manifests_dir: "/data/mops/d1d1ab47-1778-4ec6-b186-30f6a85e1756/generated"
  generated_values_dir: "/data/mops/d1d1ab47-1778-4ec6-b186-30f6a85e1756/values"
  evidence_dir: "/data/mops/d1d1ab47-1778-4ec6-b186-30f6a85e1756/evidence"
```

## 14. Final Safety Gate

Before execution, confirm:

- [ ] No secret values appear in this file.
- [ ] No production data appears in this file.
- [ ] All inferred steps are labeled.
- [ ] All required human inputs are available.
- [ ] Dry-run commands are executed before real mutation commands.
- [ ] Human approval is obtained for application-mode schema/topic cleanup.
