# BOS Genesis generated deployment artifact commands

No mutation was performed while generating this bundle.

## Helm dry-run render
helm template agent-ai-bosgenesis ./helm-chart/extracted/bosgenesis `
  --namespace agent-testing `
  --values ./helm-values/values-agent-ai-bosgenesis.yaml `
  --version unknown > ./rendered-manifests/agent-ai-bosgenesis-rendered.yaml

## Helm dry-run install
helm upgrade --install agent-ai-bosgenesis ./helm-chart/extracted/bosgenesis `
  --namespace agent-testing `
  --create-namespace `
  --values ./helm-values/values-agent-ai-bosgenesis.yaml `
  --dry-run

## Governed mutation command, only after dry-run and approval
helm upgrade --install agent-ai-bosgenesis ./helm-chart/extracted/bosgenesis `
  --namespace agent-testing `
  --create-namespace `
  --values ./helm-values/values-agent-ai-bosgenesis.yaml `
  --atomic `
  --timeout 10m

## Agent-generated ingress, apply only after Helm services exist
kubectl apply -f ./kubernetes-manifests/ingress-agent-ai-bosgenesis.yaml
