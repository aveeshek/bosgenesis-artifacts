---
artifact_type: installation_notes
schema_version: "1.0"
agent: bosgenesis-mop-creation-agent
mop_id: "dbf857a4-b1f9-4fc4-a184-a1b49b819870"
run_id: "133008be-3f28-4a2f-ab6c-73bb1f4b3fa6"
correlation_id: "mop_818ac79a8e124b0182af15a7186767c9"
generated_at: "2026-08-18T15:01:43.964689+00:00"
source_namespace: "signoz"
target_namespace: "agent-testing"
generation_mode: "platform-only"
source_snapshot: "mcp-live-859c3003-69b5-4675-af7e-400e03ade96c"
status: "generated"
no_secret_values: true
no_production_data: true
qdrant_lookup_status: "no_match"
qdrant_reference_count: 0
memory_context_status: "ok"
memory_context_read_count: 5
---

# Installation Notes: signoz to agent-testing

## 1. Purpose

Recreate the Kubernetes/Helm installation footprint from source namespace `signoz` into target namespace `agent-testing` without copying production data.

These notes are optimized for an autonomous LLM/agent executor. The executor must still require human approval before mutating any cluster or application system.

## 2. Execution Constraints

- Scope is one namespace only.
- Target namespace is `agent-testing`.
- Use public repositories only.
- Do not copy Kubernetes Secret values.
- Do not copy database rows, MongoDB documents, Kafka messages, Redis values, files, or business payloads.
- Run dry-run commands before real apply/install commands.
- Treat inferred steps as requiring human confirmation.
- Treat Qdrant references as prior guidance only, not current observed facts.
- Treat memory context as prior non-secret generation context only, not current observed facts.

## 3. Required Human Inputs

```yaml
required_human_inputs:
  []
```

## 4. Evidence Summary

```yaml
evidence:
  source_snapshot: "mcp-live-859c3003-69b5-4675-af7e-400e03ade96c"
  kubernetes_mcp:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[k8s_inspector_mcp]
  helm_mcp:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[helm_manager_mcp]
  data_ingestion:
    status: "attempted"
    references:
  - artifact.json#mcp.sources_attempted[data_ingestion_mcp]
  qdrant_prior_references:
    status: "no_match"
    count: 0
    references:
  []
  memory_context:
    status: "ok"
    count: 5
    authority: prior_context_only_not_current_fact
    records:
  - memory_id: mem-7846f8cabd463d2e
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=1; raw_k8s=3; warning_only=5. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-ee5714b50e7c4cc5
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target agent-testing. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
  - memory_id: mem-e9f5f0764245b1df
    kind: short_term
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target agent-testing. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
  - memory_id: mem-d4a5ecfaac7121ee
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=1; raw_k8s=3; warning_only=5. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-21f2d856704ff32f
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target agent-testing. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
```

## 5. Resource Inventory Summary

```yaml
inventory:
  helm_releases:
  - release_name: signoz
    namespace: signoz
    chart_name: signoz-0.122.0
    chart_version: 0.122.0
    status: failed
  raw_kubernetes_resources:
  - kind: ConfigMap
    name: istio-ca-crl
    namespace: signoz
    source: k8s_inspector_mcp
    entity_key: ConfigMap:signoz:istio-ca-crl
  - kind: ConfigMap
    name: istio-ca-root-cert
    namespace: signoz
    source: k8s_inspector_mcp
    entity_key: ConfigMap:signoz:istio-ca-root-cert
  - kind: ConfigMap
    name: kube-root-ca.crt
    namespace: signoz
    source: k8s_inspector_mcp
    entity_key: ConfigMap:signoz:kube-root-ca.crt
  application_targets:
  []
  excluded_resources:
  []
  warnings:
  - postgres_snapshot_missing: no inventory for namespace=signoz selector=latest
  - clickhouse_snapshot_missing: no inventory for namespace=signoz selector=latest
  - snapshot_inventory_missing: generated artifacts contain no discovered resources; continuing to governed MCP enrichment
  - data_ingestion_mcp_tools_list_failed: unhandled errors in a TaskGroup (1 sub-exception)
  - manual_review_required:Pod:5_runtime_artifacts_skipped
  - raw_manifest:Ingress/signoz:ingress_backend_service_rewritten:signoz->agent-ai-signoz
  - raw_manifest:Ingress/signoz:ingress_name_prefixed_from:signoz
  - raw_manifest:Ingress/signoz:ingress_reconstructed_from_helm_managed_source
  - qdrant_reference_not_found
```

## 6. Dependency Graph

```yaml
dependency_order:
  - phase: verify_access
    depends_on: []
  - phase: prepare_target_namespace
    depends_on: [verify_access]
  - phase: prepare_secret_placeholders
    depends_on: [prepare_target_namespace]
  - phase: apply_configmaps
    depends_on: [prepare_secret_placeholders]
  - phase: apply_pvcs
    depends_on: [prepare_target_namespace]
  - phase: install_helm_releases
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
  - phase: apply_raw_kubernetes_resources
    depends_on: [install_helm_releases, apply_configmaps, apply_pvcs]
  - phase: apply_ingress
    depends_on: [apply_raw_kubernetes_resources]
  - phase: apply_application_metadata
    depends_on: [apply_raw_kubernetes_resources]
    enabled_when: generation_mode == "application"
  - phase: validate
    depends_on: [apply_ingress, apply_application_metadata]
```

## 7. Machine Execution Plan

This block is the canonical machine-readable execution contract. A downstream agent should parse this YAML first, then use the remaining sections as human-readable supporting detail.

```yaml
machine_execution_plan:
  schema_version: '1.0'
  authority_order: observed_evidence > deterministic_normalization > llm_suggestion > human_fill_in
  executor_contract:
    parse_this_block_first: true
    dry_run_before_mutation: true
    human_approval_before_mutation: false
    never_copy_secret_values: true
    target_namespace_only: agent-testing
    llm_suggestions_are_not_authority: true
    qdrant_references_are_prior_guidance_only: true
  prior_references: []
  dependency_graph:
  - phase_id: verify_access
    depends_on: []
  - phase_id: prepare_target_namespace
    depends_on:
    - verify_access
  - phase_id: prepare_secret_placeholders
    depends_on:
    - prepare_target_namespace
  - phase_id: apply_configmaps
    depends_on:
    - prepare_secret_placeholders
  - phase_id: apply_pvcs
    depends_on:
    - prepare_target_namespace
  - phase_id: install_helm_releases
    depends_on:
    - apply_configmaps
    - apply_pvcs
    - prepare_secret_placeholders
  - phase_id: apply_raw_kubernetes_resources
    depends_on:
    - install_helm_releases
    - apply_configmaps
    - apply_pvcs
  - phase_id: apply_ingress
    depends_on:
    - apply_raw_kubernetes_resources
  - phase_id: apply_application_metadata
    depends_on:
    - apply_raw_kubernetes_resources
  - phase_id: validate
    depends_on:
    - apply_ingress
    - apply_application_metadata
  required_human_inputs: []
  phases:
  - phase_id: verify_access
    depends_on: []
    objective: Confirm artifact bundle, source evidence, and target namespace intent.
    steps:
    - step_id: verify-artifact-bundle
      phase_id: verify_access
      title: Verify generated artifact bundle
      type: context_check
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed
        confidence: high
        rationale: The artifact bundle is produced by this agent before execution.
      commands:
      - kind: check
        command: test -f artifact.json && test -d generated && test -d values
      expected_outcomes:
      - artifact.json, generated/, and values/ are present.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: prepare_target_namespace
    depends_on:
    - verify_access
    objective: Ensure the target namespace exists before namespaced resources are applied.
    steps:
    - step_id: prepare-target-namespace
      phase_id: prepare_target_namespace
      title: Ensure namespace agent-testing exists
      type: namespace
      depends_on: []
      evidence_refs:
      - generation_request.target_namespace
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: human_input_required
        confidence: high
        rationale: The target namespace is supplied by the generation request.
      commands:
      - kind: check
        command: kubectl get namespace agent-testing
      - kind: apply
        command: kubectl get namespace agent-testing || kubectl create namespace agent-testing
      expected_outcomes:
      - Namespace agent-testing exists.
      required_human_inputs: []
      rollback_commands:
      - 'kubectl delete namespace agent-testing # only if created for this change and cleanup is approved'
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: prepare_secret_placeholders
    depends_on:
    - prepare_target_namespace
    objective: Collect approved secret values without copying source Secret data.
    steps:
    - step_id: secret-values-not-generated
      phase_id: prepare_secret_placeholders
      title: Confirm no generated Secret values are present
      type: human_input
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: human_input_required
        confidence: high
        rationale: Secret values are excluded by policy and must not appear in artifacts.
      commands: []
      expected_outcomes:
      - Required human inputs are confirmed before execution continues.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_configmaps
    depends_on:
    - prepare_secret_placeholders
    objective: Apply generated ConfigMap manifests after namespace rewrite.
    steps:
    - step_id: apply_configmaps-1-configmap-istio-ca-crl
      phase_id: apply_configmaps
      title: Apply ConfigMap istio-ca-crl
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-crl
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-crl.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap istio-ca-crl -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-crl exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-istio-ca-crl.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-2-configmap-istio-ca-root-cert
      phase_id: apply_configmaps
      title: Apply ConfigMap istio-ca-root-cert
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-root-cert
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-root-cert.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-root-cert exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: apply_configmaps-3-configmap-kube-root-ca.crt
      phase_id: apply_configmaps
      title: Apply ConfigMap kube-root-ca.crt
      type: configmap
      depends_on:
      - prepare_secret_placeholders
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:kube-root-ca.crt
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-kube-root-ca.crt.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing
      - kind: validate
        command: kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap kube-root-ca.crt exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_pvcs
    depends_on:
    - prepare_target_namespace
    objective: Apply approved PersistentVolumeClaim manifests.
    steps: []
  - phase_id: install_helm_releases
    depends_on:
    - apply_configmaps
    - apply_pvcs
    - prepare_secret_placeholders
    objective: Install or upgrade Helm-managed components with redacted values files.
    steps:
    - step_id: helm-1-agent-ai-signoz
      phase_id: install_helm_releases
      title: Install Helm release agent-ai-signoz
      type: helm_upgrade
      depends_on:
      - apply_configmaps
      - apply_pvcs
      - prepare_secret_placeholders
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:HelmRelease:signoz:signoz
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-signoz.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as public chart evidence; values are redacted before use.
      commands:
      - kind: dry_run
        command: helm upgrade --install agent-ai-signoz signoz/signoz --namespace agent-testing --create-namespace --version
          0.122.0 -f values/values-agent-ai-signoz.yaml --dry-run
      - kind: apply
        command: helm upgrade --install agent-ai-signoz signoz/signoz --namespace agent-testing --create-namespace --version
          0.122.0 -f values/values-agent-ai-signoz.yaml --atomic --timeout 10m
      - kind: validate
        command: helm status agent-ai-signoz -n agent-testing
      expected_outcomes:
      - Helm release agent-ai-signoz is deployed in agent-testing.
      required_human_inputs: []
      rollback_commands:
      - helm uninstall agent-ai-signoz -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-signoz
      source_release_name: signoz
      chart_ref: signoz/signoz
      chart_version: 0.122.0
      chart_source: public
      repo_name: signoz
      repo_url: https://charts.signoz.io
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
  - phase_id: apply_raw_kubernetes_resources
    depends_on:
    - install_helm_releases
    - apply_configmaps
    - apply_pvcs
    objective: Apply supported non-Helm Kubernetes resources in deterministic order.
    steps: []
  - phase_id: apply_ingress
    depends_on:
    - apply_raw_kubernetes_resources
    objective: Apply Ingress resources after backend services are present.
    steps:
    - step_id: apply_ingress-1-ingress-agent-ai-signoz
      phase_id: apply_ingress
      title: Apply Ingress agent-ai-signoz
      type: ingress
      depends_on:
      - apply_raw_kubernetes_resources
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:Ingress:signoz:signoz
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-signoz.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Manifest was normalized from available namespace evidence.
      commands:
      - kind: dry_run
        command: kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n agent-testing --dry-run=server -o yaml
      - kind: apply
        command: kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n agent-testing
      - kind: validate
        command: kubectl get ingress agent-ai-signoz -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-signoz exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands:
      - kubectl delete -f generated/ingress-agent-ai-signoz.yaml -n agent-testing --ignore-not-found
      mutates_target: true
      requires_human_approval: true
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
  - phase_id: apply_application_metadata
    depends_on:
    - apply_raw_kubernetes_resources
    objective: Application-mode metadata recreation is deferred until application evidence exists.
    steps: []
    enabled_when: generation_mode == "application"
  - phase_id: validate
    depends_on:
    - apply_ingress
    - apply_application_metadata
    objective: Confirm generated resources are visible and healthy in the target namespace.
    steps:
    - step_id: validate-preflight-1
      phase_id: validate
      title: Run validation command 1
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: validate
        command: kubectl get all,configmap,pvc,ingress -n agent-testing
      expected_outcomes:
      - Command succeeds and expected resources are visible.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-preflight-2
      phase_id: validate
      title: Run validation command 2
      type: context_check
      depends_on: []
      evidence_refs:
      - artifact.json
      qdrant_refs: []
      manifest_refs: []
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: validate
        command: helm list -n agent-testing
      expected_outcomes:
      - Command succeeds and expected resources are visible.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-helm-1-agent-ai-signoz
      phase_id: validate
      title: Validate Helm release agent-ai-signoz
      type: helm_validate
      depends_on: []
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:HelmRelease:signoz:signoz
      qdrant_refs: []
      manifest_refs: []
      values_refs:
      - values/values-agent-ai-signoz.yaml
      inference:
        label: observed
        confidence: medium
        rationale: Chart reference was supplied as public chart evidence; values are redacted before use.
      commands:
      - kind: helm_validate
        command: helm template agent-ai-signoz signoz/signoz --namespace agent-testing -f values/values-agent-ai-signoz.yaml
          --version 0.122.0
      - kind: helm_status
        command: helm status agent-ai-signoz -n agent-testing
      expected_outcomes:
      - Helm chart signoz/signoz renders for release agent-ai-signoz.
      - Helm release agent-ai-signoz is visible in agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
      release_name: agent-ai-signoz
      source_release_name: signoz
      chart_ref: signoz/signoz
      chart_version: 0.122.0
      chart_source: public
      repo_name: signoz
      repo_url: https://charts.signoz.io
      credential_secret_ref: null
      generated_by: bosgenesis-mop-creation-agent
    - step_id: validate-k8s-1-configmap-istio-ca-crl
      phase_id: validate
      title: Validate ConfigMap istio-ca-crl
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-crl
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-crl.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap istio-ca-crl -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-crl exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-2-configmap-istio-ca-root-cert
      phase_id: validate
      title: Validate ConfigMap istio-ca-root-cert
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-root-cert
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-istio-ca-root-cert.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap istio-ca-root-cert exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-3-configmap-kube-root-ca.crt
      phase_id: validate
      title: Validate ConfigMap kube-root-ca.crt
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:kube-root-ca.crt
      qdrant_refs: []
      manifest_refs:
      - generated/configmap-kube-root-ca.crt.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
      expected_outcomes:
      - ConfigMap kube-root-ca.crt exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
    - step_id: validate-k8s-4-ingress-agent-ai-signoz
      phase_id: validate
      title: Validate Ingress agent-ai-signoz
      type: k8s_validate
      depends_on: []
      evidence_refs:
      - mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:Ingress:signoz:signoz
      qdrant_refs: []
      manifest_refs:
      - generated/ingress-agent-ai-signoz.yaml
      values_refs: []
      inference:
        label: observed_or_inferred
        confidence: medium
        rationale: Validation confirms generated platform resources.
      commands:
      - kind: k8s_validate
        command: kubectl get ingress agent-ai-signoz -n agent-testing -o wide
      expected_outcomes:
      - Ingress agent-ai-signoz exists in namespace agent-testing.
      required_human_inputs: []
      rollback_commands: []
      mutates_target: false
      requires_human_approval: false
      on_failure: STOP and resolve the evidence or generated artifact before continuing.
```

## 8. Execution Phases

Each command-bearing step inside a phase must use this shape:

```yaml
step:
  step_id: "<stable-phase-local-id>"
  title: "<short action title>"
  type: "context_check | namespace | secret_placeholder | configmap | pvc | helm | kubernetes | ingress | application_metadata | validation | rollback"
  depends_on: []
  evidence_refs: []
  qdrant_refs: []
  inference:
    label: "observed | inferred | prior_reference | human_input_required"
    confidence: "high | medium | low"
    rationale: "<why this step exists>"
  command: |
    <copyable command or human-action placeholder>
  expected: "<expected state or output>"
  on_failure: "<STOP, investigate, or rollback instruction>"
  mutates_target: true
  requires_human_approval: true
```

### Phase 1 - Verify Access

```yaml
phase_id: verify_access
objective: Confirm source/target context, namespace visibility, and tool availability.
commands:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - Snapshot and MCP inventory evidence is represented in generated artifacts.
stop_conditions:
  - Local artifact directory is not writable.
evidence_refs:
  - artifact.json
```

### Phase 2 - Prepare Target Namespace

```yaml
phase_id: prepare_target_namespace
objective: Ensure target namespace exists before applying namespaced resources.
commands:
  - step_id: prepare-target-namespace
    title: Ensure target namespace exists
    type: namespace
    depends_on: [verify_access]
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: high
      rationale: Target namespace is supplied by the generation request.
    command: |
      kubectl get namespace agent-testing || kubectl create namespace agent-testing
      kubectl get namespace agent-testing
    expected: Namespace agent-testing exists.
    on_failure: STOP and confirm namespace creation is approved.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Namespace agent-testing exists.
rollback:
  - Delete the target namespace only if it was created for this change and cleanup is approved.
evidence_refs:
  - artifact.json
```

### Phase 3 - Prepare Secret Placeholders

```yaml
phase_id: prepare_secret_placeholders
objective: Ensure required secret names and keys exist using approved secure values.
manual_inputs:
  []
commands:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - No secrets are generated or copied.
stop_conditions:
  - Missing approved secret material.
  - Any generated content contains secret values.
evidence_refs:
  - artifact.json
```

### Phase 4 - Apply ConfigMaps

```yaml
phase_id: apply_configmaps
objective: Apply generated ConfigMap manifests after namespace rewrite and redaction.
commands:
  - step_id: raw-1-configmap-istio-ca-crl
    title: Apply ConfigMap istio-ca-crl
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-crl.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-crl]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-istio-ca-crl.yaml -n agent-testing
    expected: ConfigMap istio-ca-crl exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-2-configmap-istio-ca-root-cert
    title: Apply ConfigMap istio-ca-root-cert
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-root-cert.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-root-cert]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing
    expected: ConfigMap istio-ca-root-cert exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
  - step_id: raw-3-configmap-kube-root-ca.crt
    title: Apply ConfigMap kube-root-ca.crt
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/configmap-kube-root-ca.crt.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:kube-root-ca.crt]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing
    expected: ConfigMap kube-root-ca.crt exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - ConfigMaps are accepted by dry-run and then applied when approved.
rollback:
  - kubectl delete -f generated/configmap-kube-root-ca.crt.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-istio-ca-root-cert.yaml -n agent-testing --ignore-not-found
  - kubectl delete -f generated/configmap-istio-ca-crl.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 5 - Apply PVCs

```yaml
phase_id: apply_pvcs
objective: Create approved PVCs when storage class and capacity are confirmed.
commands:
  []
expected_outcomes:
  - PVCs are accepted by dry-run and then applied when approved.
rollback:
  - No rollback required.
evidence_refs:
  - artifact.json
```

### Phase 6 - Install Helm Releases

```yaml
phase_id: install_helm_releases
objective: Recreate Helm-managed components using generated values files.
step_contract:
  dry_run_required: true
  real_install_requires_successful_dry_run: true
  chart_sources_must_be_public: true
commands:
  - step_id: helm-1-agent-ai-signoz
    title: Install Helm release agent-ai-signoz
    type: helm_upgrade
    release_name: agent-ai-signoz
    source_release_name: signoz
    chart_source: public
    chart_ref: signoz/signoz
    chart_version: 0.122.0
    repo_name: signoz
    repo_url: https://charts.signoz.io
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-signoz.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: [apply_configmaps, apply_pvcs, prepare_secret_placeholders]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:HelmRelease:signoz:signoz]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as public chart evidence; values are redacted before use.
    command: |
      helm upgrade --install agent-ai-signoz signoz/signoz --namespace agent-testing --create-namespace --version 0.122.0 -f values/values-agent-ai-signoz.yaml --dry-run
      helm upgrade --install agent-ai-signoz signoz/signoz --namespace agent-testing --create-namespace --version 0.122.0 -f values/values-agent-ai-signoz.yaml --atomic --timeout 10m
    expected: Helm release agent-ai-signoz is deployed.
    on_failure: STOP; inspect Helm output and generated values file.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Helm dry-runs render successfully before install commands are executed.
rollback:
  - helm uninstall agent-ai-signoz -n agent-testing --ignore-not-found
unknowns:
  []
evidence_refs:
TBD
```

### Phase 7 - Apply Raw Kubernetes Resources

```yaml
phase_id: apply_raw_kubernetes_resources
objective: Apply supported non-Helm resources in dependency order.
step_contract:
  dry_run_required: true
  namespace_explicit: true
  blocked_kinds_must_be_excluded: true
commands:
  []
expected_outcomes:
  - Raw Kubernetes manifests are accepted by server-side dry-run before apply.
rollback:
  - No rollback required.
evidence_refs:
  - artifact.json
```

### Phase 8 - Apply Ingress

```yaml
phase_id: apply_ingress
objective: Apply ingress resources after backend services are available.
commands:
  - step_id: raw-1-ingress-agent-ai-signoz
    title: Apply Ingress agent-ai-signoz
    type: kubernetes
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-signoz.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:Ingress:signoz:signoz]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Manifest was normalized from available namespace evidence.
    command: |
      kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n agent-testing --dry-run=server -o yaml
      kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n agent-testing
    expected: Ingress agent-ai-signoz exists in agent-testing.
    on_failure: STOP; fix generated manifest and repeat dry-run.
    mutates_target: true
    requires_human_approval: true
expected_outcomes:
  - Ingress resources are accepted by dry-run and then applied when approved.
rollback:
  - kubectl delete -f generated/ingress-agent-ai-signoz.yaml -n agent-testing --ignore-not-found
evidence_refs:
  - artifact.json
```

### Phase 9 - Application Metadata Recreation

```yaml
phase_id: apply_application_metadata
enabled_when: generation_mode == "application"
objective: Recreate metadata-only schemas, topics, and topology without data.
targets:
  []
commands_or_guidance:
  - step_id: phase6-placeholder
    title: Phase 6 placeholder
    type: validation
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: human_input_required
      confidence: low
      rationale: Phase 6 generates platform reconstruction commands from classified inventory.
    command: |
      echo "Phase 6 placeholder only"
    expected: No target system changes are made.
    on_failure: STOP and inspect the local artifact bundle.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - No schemas, topics, or topology are created.
rollback:
  - No rollback required.
evidence_refs:
  - artifact.json
```

### Phase 10 - Validate

```yaml
phase_id: validate
objective: Confirm recreated namespace resources are healthy.
commands:
  - step_id: validate-preflight-1
    title: Validation command 1
    type: k8s_validate
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get all,configmap,pvc,ingress -n agent-testing
    expected: Command succeeds and expected resources are visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-preflight-2
    title: Validation command 2
    type: context_check
    depends_on: []
    evidence_refs: []
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      helm list -n agent-testing
    expected: Command succeeds and expected resources are visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-helm-1-agent-ai-signoz
    title: Validate Helm release agent-ai-signoz
    type: helm_validate
    release_name: agent-ai-signoz
    chart_source: public
    chart_ref: signoz/signoz
    chart_version: 0.122.0
    repo_name: signoz
    repo_url: https://charts.signoz.io
    credential_secret_ref: 
    values_refs: [values/values-agent-ai-signoz.yaml]
    generated_by: bosgenesis-mop-creation-agent
    depends_on: []
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:HelmRelease:signoz:signoz]
    qdrant_refs: []
    inference:
      label: observed
      confidence: medium
      rationale: Chart reference was supplied as public chart evidence; values are redacted before use.
    command: |
      helm template agent-ai-signoz signoz/signoz --namespace agent-testing -f values/values-agent-ai-signoz.yaml --version 0.122.0
      helm status agent-ai-signoz -n agent-testing
    expected: Helm chart renders and release status is visible.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-1-ConfigMap-istio-ca-crl
    title: Validate ConfigMap istio-ca-crl
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-crl.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-crl]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap istio-ca-crl -n agent-testing -o wide
    expected: ConfigMap istio-ca-crl exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-2-ConfigMap-istio-ca-root-cert
    title: Validate ConfigMap istio-ca-root-cert
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-istio-ca-root-cert.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:istio-ca-root-cert]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap istio-ca-root-cert -n agent-testing -o wide
    expected: ConfigMap istio-ca-root-cert exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-3-ConfigMap-kube-root-ca.crt
    title: Validate ConfigMap kube-root-ca.crt
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/configmap-kube-root-ca.crt.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:ConfigMap:signoz:kube-root-ca.crt]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get configmap kube-root-ca.crt -n agent-testing -o wide
    expected: ConfigMap kube-root-ca.crt exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
  - step_id: validate-k8s-4-Ingress-agent-ai-signoz
    title: Validate Ingress agent-ai-signoz
    type: k8s_validate
    depends_on: []
    manifest_refs: [generated/ingress-agent-ai-signoz.yaml]
    evidence_refs: [mcp_live:mcp-live-859c3003-69b5-4675-af7e-400e03ade96c:Ingress:signoz:signoz]
    qdrant_refs: []
    inference:
      label: observed_or_inferred
      confidence: medium
      rationale: Validation confirms generated platform resources.
    command: |
      kubectl get ingress agent-ai-signoz -n agent-testing -o wide
    expected: Ingress agent-ai-signoz exists in namespace agent-testing.
    on_failure: STOP and inspect target namespace.
    mutates_target: false
    requires_human_approval: false
expected_outcomes:
  - Generated files exist and target namespace dry-run commands succeed.
stop_conditions:
  - Required MoP sections are missing.
evidence_refs:
  - artifact.json
```

## 9. Go / No-Go Matrix

```yaml
go_no_go:
  - checkpoint: Required artifact files exist
    expected: true
    action_if_failed: STOP
```

## 10. Rollback Plan

```yaml
rollback:
  trigger_conditions:
  - Any approved install/apply command fails after mutation begins.
  helm:
  - helm uninstall agent-ai-signoz -n agent-testing --ignore-not-found
  raw_kubernetes:
  - No rollback required.
  application_metadata:
  - No rollback required.
  namespace_cleanup:
  - Delete target namespace only with explicit approval.
```

## 11. Inference and Confidence

```yaml
inferences:
  - label: observed_or_inferred
    confidence: medium
    rationale: Deterministic reconstruction writes normalized manifests and Helm values from available evidence; missing chart refs or specs require human completion.
    authority_order: Observed evidence > deterministic reconstruction > Qdrant prior references > LLM suggestion > human approval
  - label: bounded_llm_reasoning_no_high_confidence_findings
    confidence: high
    rationale: No executable YAML or Helm command was generated by the bounded reasoning layer.
    executable_yaml_allowed: false
  - label: llm_repair_no_high_confidence_suggestions
    confidence: high
    rationale: No executable YAML was generated by the LLM repair layer.
    executable_yaml_allowed: false
unknowns:
  - Exact install command synthesis requires a later generation phase.
  - Secret values are intentionally unavailable and must be supplied by humans.
confidence_summary:
  overall: medium_when_snapshot_found_low_when_missing
  bounded_llm_reasoning_status: no_high_confidence_findings
  bounded_llm_reasoning_accepted_findings: 0
  llm_repair_status: no_high_confidence_suggestions
  llm_repair_accepted_suggestions: 0
  llm_output_authoritative: false
```

## 12. Excluded Resources

```yaml
excluded_resources:
  []
exclusion_policy:
  - Secret values are never copied.
  - Cluster-scoped resources are out of v1 scope.
  - Unsupported namespaced resources require manual review.
```

## 13. Artifact References

```yaml
artifacts:
  human_mop_pdf: "/data/mops/dbf857a4-b1f9-4fc4-a184-a1b49b819870/mop-signoz-to-agent-testing-20260818T150143Z.pdf"
  installation_notes: "/data/mops/dbf857a4-b1f9-4fc4-a184-a1b49b819870/mop-signoz-to-agent-testing-20260818T150143Z.installation.md"
  generated_manifests_dir: "/data/mops/dbf857a4-b1f9-4fc4-a184-a1b49b819870/generated"
  generated_values_dir: "/data/mops/dbf857a4-b1f9-4fc4-a184-a1b49b819870/values"
  evidence_dir: "/data/mops/dbf857a4-b1f9-4fc4-a184-a1b49b819870/evidence"
```

## 14. Final Safety Gate

Before execution, confirm:

- [ ] No secret values appear in this file.
- [ ] No production data appears in this file.
- [ ] All inferred steps are labeled.
- [ ] All required human inputs are available.
- [ ] Dry-run commands are executed before real mutation commands.
- [ ] Human approval is obtained for application-mode schema/topic cleanup.
