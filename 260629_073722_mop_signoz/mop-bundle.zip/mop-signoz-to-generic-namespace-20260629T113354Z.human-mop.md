# MoP: Namespace Recreation MoP - signoz to generic-namespace

---

## Document Header

| Field | Value |
|---|---|
| **MoP Title** | Namespace Recreation MoP - signoz to generic-namespace |
| **MoP ID** | 20ad27cc-5b73-461c-8965-7e9c317493c1 |
| **Version** | 0.6.0-phase6 |
| **Generator** | bosgenesis-mop-creation-agent |
| **Generated At** | 2026-06-29T11:33:54.019407+00:00 |
| **Reviewed By** | TBD |
| **Change Ticket** | TBD |
| **Change Window** | TBD |
| **Estimated Duration** | TBD |
| **Risk Level** | TBD |
| **Rollback Time** | TBD |
| **Rollback Approver** | TBD |
| **Source Namespace** | signoz |
| **Target Namespace** | generic-namespace |
| **Generation Mode** | platform-only |
| **Source Snapshot** | mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27 |
| **Run ID** | e7936acc-08e9-45b0-8aef-b44f56a36d02 |
| **Correlation ID** | mop_661bb6d8530b4d0ca585008152c4245b |

---

## Change Summary

**What:** Recreate the Kubernetes and Helm installation footprint from source namespace `signoz` into target namespace `generic-namespace`.

**Why:** Phase 6 platform reconstruction artifact generation with normalized raw manifests and Helm value files.

**Impact:** This MoP creates or updates target namespace resources only. It does not copy production data and does not migrate Kubernetes Secret values.

| Category | Count | Notes |
|---|---:|---|
| Helm releases | 1 | Executable Helm plans generated for releases: agent-ai-signoz |
| Raw Kubernetes resources | 3 | ConfigMap=3 |
| Application-mode targets | 0 | Application mode metadata discovery is not executed in Phase 6. |
| Excluded resources | 0 | No blocked or out-of-scope resources were classified for exclusion. |
| Warnings | 9 | postgres_snapshot_missing: no inventory for namespace=signoz selector=latest; clickhouse_snapshot_missing: no inventory for namespace=signoz selector=latest; snapshot_inventory_missing: generated artifacts contain no discovered resources; continuing to governed MCP enrichment; data_ingestion_mcp_tools_list_failed: unhandled errors in a TaskGroup (1 sub-exception); manual_review_required:Pod:5_runtime_artifacts_skipped; raw_manifest:Ingress/signoz:ingress_backend_service_rewritten:signoz->agent-ai-signoz; raw_manifest:Ingress/signoz:ingress_name_prefixed_from:signoz; raw_manifest:Ingress/signoz:ingress_reconstructed_from_helm_managed_source; qdrant_reference_not_found |

**Assumptions:**

- Stored ETL snapshots are preferred when available.
- Live Kubernetes and Helm reads are performed only through governed MCP servers.

**Unknowns / Required Human Inputs:**

- Exact install command synthesis requires a later generation phase.
- Secret values are intentionally unavailable and must be supplied by humans.

---

## Pre-change Checklist

Before starting, confirm all items are checked:

- [ ] Change ticket or approval reference is recorded: `TBD`
- [ ] Operator has access to the source cluster context and target cluster context.
- [ ] Target namespace name is confirmed: `generic-namespace`
- [ ] Required secret material is available from approved secure sources.
- [ ] Generated Helm values and manifests have been reviewed for redaction and namespace rewrite.
- [ ] Required public Helm repositories and chart references are reachable.
- [ ] Rollback approver is available: `TBD`
- [ ] Application-mode schema/topology guidance, if present, has been reviewed by the application owner.

---

## 1. Access & Environment Verification

**Step 1.1 - Confirm active Kubernetes context**

```bash
kubectl config current-context
```

**Expected output:**

```text
TBD
```

> STOP if the context is not the intended target cluster.

---

**Step 1.2 - Verify source namespace visibility**

```bash
kubectl get namespace signoz
kubectl get all -n signoz
```

**Expected output:** Namespace exists and source workloads are visible to the operator.

> STOP if the source namespace cannot be inspected. Regenerate this MoP after source evidence is refreshed.

---

**Step 1.3 - Verify or create target namespace**

```bash
kubectl get namespace generic-namespace || kubectl create namespace generic-namespace
kubectl get namespace generic-namespace
```

**Expected output:** Target namespace `generic-namespace` exists.

> STOP if namespace creation is not approved for this change.

---

**Step 1.4 - Verify Helm availability**

```bash
helm version
helm list -n generic-namespace
```

**Expected output:** Helm is installed and can query the target namespace.

---

**Step 1.5 - Verify generated artifact bundle**

```bash
ls -lh /data/mops/20ad27cc-5b73-461c-8965-7e9c317493c1
find /data/mops/20ad27cc-5b73-461c-8965-7e9c317493c1 -maxdepth 2 -type f | sort
```

**Expected output:** Generated values, manifests, and evidence references are available.

---

## 2. Pre-change Backup

**Step 2.1 - Export source namespace summary**

```bash
kubectl get all,configmap,pvc,ingress -n signoz -o wide \
  > /data/mops/20ad27cc-5b73-461c-8965-7e9c317493c1/evidence/signoz-summary-$(date +%F-%H%M).txt
```

**Expected output:** Source namespace summary file is created.

---

**Step 2.2 - Export source manifests without Secret values**

```bash
kubectl get configmap,service,deployment,statefulset,daemonset,job,cronjob,pvc,ingress \
  -n signoz -o yaml \
  > /data/mops/20ad27cc-5b73-461c-8965-7e9c317493c1/evidence/signoz-non-secret-manifests-$(date +%F-%H%M).yaml
```

**Expected output:** Non-secret source manifest reference is created.

> Do not export Kubernetes Secret data into this backup bundle.

---

**Step 2.3 - Export Helm release references**

```bash
helm list -n signoz > /data/mops/20ad27cc-5b73-461c-8965-7e9c317493c1/evidence/signoz-helm-releases-$(date +%F-%H%M).txt
echo "Review redacted Helm values: values/values-agent-ai-signoz.yaml"
```

**Expected output:** Helm release list and approved values references are captured.

---

## 3. Stakeholder Notification

**Step 3.1 - Notify start of namespace recreation**

Post in the approved deployment channel:

```text
[STARTING] 20ad27cc-5b73-461c-8965-7e9c317493c1 - recreating namespace signoz into generic-namespace
Mode: platform-only
Change window: TBD
Rollback approver: TBD
Run ID: e7936acc-08e9-45b0-8aef-b44f56a36d02
```

---

## 4. Deployment Execution

### 4.1 Target Namespace Preparation

**Step 4.1 - Target namespace preparation placeholder**

```bash
echo "Phase 6 placeholder: Target namespace preparation"
```

**Expected output:** No target system changes are made.

> STOP if this placeholder appears in a production execution package.

---

### 4.2 Secret Placeholders and Required Inputs

The agent does not copy Kubernetes Secret values. Create required secrets manually from approved secure sources before applying workloads that depend on them.

| Secret Name | Required Keys | Source / Owner | Status |
|---|---|---|---|
| TBD | TBD | TBD | Pending |

No secret values are read or generated in Phase 6.

---

### 4.3 ConfigMaps and Static Configuration

**Step 4.3.1 - Apply ConfigMap `istio-ca-crl`**

Dry-run first:

```bash
kubectl apply -f generated/configmap-istio-ca-crl.yaml -n generic-namespace --dry-run=server -o yaml
```

Apply after approval:

```bash
kubectl apply -f generated/configmap-istio-ca-crl.yaml -n generic-namespace
```

**Expected output:** ConfigMap `istio-ca-crl` exists in namespace `generic-namespace`.

**Manifest:** `generated/configmap-istio-ca-crl.yaml`

**Evidence:** mcp_live:mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27:ConfigMap:signoz:istio-ca-crl

---

**Step 4.3.2 - Apply ConfigMap `istio-ca-root-cert`**

Dry-run first:

```bash
kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n generic-namespace --dry-run=server -o yaml
```

Apply after approval:

```bash
kubectl apply -f generated/configmap-istio-ca-root-cert.yaml -n generic-namespace
```

**Expected output:** ConfigMap `istio-ca-root-cert` exists in namespace `generic-namespace`.

**Manifest:** `generated/configmap-istio-ca-root-cert.yaml`

**Evidence:** mcp_live:mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27:ConfigMap:signoz:istio-ca-root-cert

---

**Step 4.3.3 - Apply ConfigMap `kube-root-ca.crt`**

Dry-run first:

```bash
kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n generic-namespace --dry-run=server -o yaml
```

Apply after approval:

```bash
kubectl apply -f generated/configmap-kube-root-ca.crt.yaml -n generic-namespace
```

**Expected output:** ConfigMap `kube-root-ca.crt` exists in namespace `generic-namespace`.

**Manifest:** `generated/configmap-kube-root-ca.crt.yaml`

**Evidence:** mcp_live:mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27:ConfigMap:signoz:kube-root-ca.crt

---

### 4.4 Persistent Volume Claims

**Step 4.4 - PersistentVolumeClaim recreation placeholder**

```bash
echo "Phase 6 placeholder: PersistentVolumeClaim recreation"
```

**Expected output:** No target system changes are made.

> STOP if this placeholder appears in a production execution package.

---

### 4.5 Helm Release Recreation

For each Helm release, run the dry-run command first. Proceed only after dry-run output is reviewed.

**Step 4.5.1 - Install Helm release `agent-ai-signoz`**

Dry-run first:

```bash
helm upgrade --install agent-ai-signoz signoz/signoz --namespace generic-namespace --create-namespace --version 0.122.0 -f values/values-agent-ai-signoz.yaml --dry-run
```

Install after approval:

```bash
helm upgrade --install agent-ai-signoz signoz/signoz --namespace generic-namespace --create-namespace --version 0.122.0 -f values/values-agent-ai-signoz.yaml --atomic --timeout 10m
```

**Expected output:** Helm release `agent-ai-signoz` is deployed in namespace `generic-namespace`.

**Values:** `values/values-agent-ai-signoz.yaml`

**Chart source:** `public`

**Evidence:** mcp_live:mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27:HelmRelease:signoz:signoz

---

### 4.6 Raw Kubernetes Resource Recreation

Apply generated manifests in dependency order. Run server-side dry-run before each real apply.

**Step 4.6 - Raw Kubernetes recreation placeholder**

```bash
echo "Phase 6 placeholder: Raw Kubernetes recreation"
```

**Expected output:** No target system changes are made.

> STOP if this placeholder appears in a production execution package.

---

### 4.7 Ingress and External Routing

**Step 4.7.1 - Apply Ingress `agent-ai-signoz`**

Dry-run first:

```bash
kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n generic-namespace --dry-run=server -o yaml
```

Apply after approval:

```bash
kubectl apply -f generated/ingress-agent-ai-signoz.yaml -n generic-namespace
```

**Expected output:** Ingress `agent-ai-signoz` exists in namespace `generic-namespace`.

**Manifest:** `generated/ingress-agent-ai-signoz.yaml`

**Evidence:** mcp_live:mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27:Ingress:signoz:signoz

**Warnings:** ingress_backend_service_rewritten:signoz->agent-ai-signoz; ingress_name_prefixed_from:signoz; ingress_reconstructed_from_helm_managed_source

---

### 4.8 Application Schema / Topology Recreation

This section appears only when `application` mode is selected. It must recreate metadata/schema/topology only, never production data.

**Step 4.8 - Application metadata recreation placeholder**

```bash
echo "Phase 6 placeholder: Application metadata recreation"
```

**Expected output:** No target system changes are made.

> STOP if this placeholder appears in a production execution package.

---

## 5. Validation

**Step 5.1 - Validate Helm releases**

```bash
helm list -n generic-namespace
helm status agent-ai-signoz -n generic-namespace
```

**Expected output:** Expected Helm releases are deployed and healthy.

---

**Step 5.2 - Validate workloads**

```bash
kubectl get deployment,statefulset,daemonset,job,cronjob -n generic-namespace
kubectl get pods -n generic-namespace -o wide
```

**Expected output:** Workloads are available, and pods are Running or Completed as appropriate.

> STOP and investigate if any pod shows `CrashLoopBackOff`, `Error`, or unexpected restarts.

---

**Step 5.3 - Validate services and endpoints**

```bash
kubectl get service,endpoints -n generic-namespace
```

**Expected output:** Services exist and endpoints are populated where expected.

---

**Step 5.4 - Validate ingress**

```bash
kubectl get ingress -n generic-namespace
kubectl get ingress agent-ai-signoz -n generic-namespace -o wide
```

**Expected output:** Ingress resources exist with expected host/path values.

---

**Step 5.5 - Validate application-mode metadata**

**Step 5.5 - Application metadata validation placeholder**

```bash
echo "Phase 6 placeholder: Application metadata validation"
```

**Expected output:** No target system changes are made.

> STOP if this placeholder appears in a production execution package.

---

## 6. Go / No-Go Decision Points

| # | Checkpoint | Expected Result | Outcome | Action if Failed |
|---|---|---|---|---|
| 1 | Target namespace confirmed | `generic-namespace` exists | Pass / Fail | STOP - fix namespace |
| 2 | Secret placeholders resolved | Required secret material created manually | Pass / Fail | STOP - resolve secrets |
| 3 | Helm dry-runs pass | No render/template errors | Pass / Fail | STOP - fix chart/values |
| 4 | Kubectl dry-runs pass | Server accepts manifests | Pass / Fail | STOP - fix manifests |
| 5 | Workloads healthy | Desired replicas ready | Pass / Fail | ROLLBACK or investigate |
| 6 | Services/endpoints healthy | Endpoints populated where expected | Pass / Fail | ROLLBACK or investigate |
| 7 | Ingress valid | Hosts/paths visible | Pass / Fail | Fix ingress or rollback |
| 8 | Application metadata valid | Schemas/topics/topology present, no data copied | Pass / Fail | Manual review |

---

## 7. Rollback Procedure

> Trigger rollback if any Go/No-Go check fails after deployment begins.

**Step 7.1 - Notify rollback is starting**

```text
[ROLLBACK STARTING] 20ad27cc-5b73-461c-8965-7e9c317493c1 - target namespace generic-namespace
Reason: <describe failure>
Run ID: e7936acc-08e9-45b0-8aef-b44f56a36d02
```

---

**Step 7.2 - Roll back Helm releases**

```bash
helm uninstall agent-ai-signoz -n generic-namespace --ignore-not-found
```

---

**Step 7.3 - Remove raw Kubernetes resources**

```bash
kubectl delete -f generated/ingress-agent-ai-signoz.yaml -n generic-namespace --ignore-not-found
kubectl delete -f generated/configmap-kube-root-ca.crt.yaml -n generic-namespace --ignore-not-found
kubectl delete -f generated/configmap-istio-ca-root-cert.yaml -n generic-namespace --ignore-not-found
kubectl delete -f generated/configmap-istio-ca-crl.yaml -n generic-namespace --ignore-not-found
```

---

**Step 7.4 - Application-mode cleanup**

No application metadata was created in Phase 6.

> Application schema/topic cleanup can be destructive. Require human review before running cleanup commands.

---

**Step 7.5 - Optional namespace cleanup**

Only run this if the target namespace was newly created for this change and namespace deletion is approved.

```bash
kubectl delete namespace generic-namespace
```

---

**Step 7.6 - Notify rollback complete**

```text
[ROLLBACK COMPLETE] 20ad27cc-5b73-461c-8965-7e9c317493c1 - target namespace generic-namespace
Rollback duration: <X> minutes
Follow-up ticket: <link>
```

---

## 8. Post-Change Activities

- [ ] Update change ticket with final status: Success / Rolled Back / Partial.
- [ ] Attach this MoP PDF and generated installation notes.
- [ ] Attach generated manifest/value/evidence bundle references.
- [ ] Record any command deviations from the MoP.
- [ ] Confirm no production data or secret values were copied.
- [ ] If rolled back, open follow-up defect or post-incident review.
- [ ] If successful, hand off target namespace validation results to the application owner.

---

## Execution Log

| Time (UTC) | Step | Operator | Result | Notes |
|---|---|---|---|---|
|  | Start - context verified |  | Pass / Fail |  |
|  | Pre-checks complete |  | Pass / Fail |  |
|  | Backup captured |  | Pass / Fail |  |
|  | Stakeholders notified |  | Pass / Fail |  |
|  | Secrets prepared |  | Pass / Fail |  |
|  | Helm dry-runs complete |  | Pass / Fail |  |
|  | Kubernetes dry-runs complete |  | Pass / Fail |  |
|  | Deployment complete |  | Pass / Fail |  |
|  | Validation complete |  | Pass / Fail |  |
|  | Change closed |  | Pass / Fail |  |

---

## Evidence and Inference Appendix

### Evidence References

- mcp_live: snapshot_id=mcp-live-1e4693b6-dc1c-40eb-b03e-57921666ea27, resources=37, helm_releases=1.
- Snapshot sources attempted: postgres, clickhouse.
- MCP sources attempted: k8s_inspector_mcp, helm_manager_mcp, data_ingestion_mcp.

### Qdrant Prior References

- qdrant_lookup_status: no_match
- authority: prior_reference_only_not_current_observed_fact
- qdrant_references: none

### Agentic Memory Context

Memory context is prior non-secret generation context only. It is not current observed evidence and must not be used as an execution authority.

```yaml
status: "ok"
read_count: 5
authority: prior_context_only_not_current_fact
records:
  - memory_id: mem-6772bbc0cff5e568
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=1; raw_k8s=3; warning_only=5. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-b14fd8724dd1d19b
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
  - memory_id: mem-432116de86e2c1b4
    kind: short_term
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
  - memory_id: mem-835c9732a0c9669e
    kind: knowledge
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: 'Namespace pattern: helm_releases=1; raw_k8s=3; warning_only=5. Use only as prior
  context; current evidence remains authoritative.'
  - memory_id: mem-aa8796cde83ce9bc
    kind: episodic
    authority: prior_context_only_not_current_fact
    confidence: medium
    redaction_status: non_secret_summary_only
    summary: Generated namespace reconstruction summary for target generic-namespace. Resources=37,
  helm_releases=1, raw_k8s=3, warning_only=5, qdrant_references=0, warnings=9.
...
```

### Inferred Guidance

- bounded_reasoning_authority_order: Observed evidence > deterministic reconstruction > Qdrant prior references > LLM suggestion > human approval
- bounded_llm_reasoning_status: no_high_confidence_findings
- langgraph_used: true
- llm_output_authoritative: false
- bounded_reasoning_findings: none
- authority_order: Observed evidence > deterministic normalization > LLM suggestion > human fill-in
- llm_repair_suggestions_status: no_high_confidence_suggestions
- llm_suggestions: none

### Excluded Resources

- No blocked or out-of-scope resources were observed.

---

*MoP generated by bosgenesis-mop-creation-agent | source=signoz | target=generic-namespace | run_id=e7936acc-08e9-45b0-8aef-b44f56a36d02 | correlation_id=mop_661bb6d8530b4d0ca585008152c4245b*
